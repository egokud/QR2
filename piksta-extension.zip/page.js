const API_URL = 'https://mobile.yangkeduo.com/proxy/api/api/aristotle/order_list_v4';
const FIREBASE_PROJECT = 'parcel-scanner-90427';

let allResults = [];
let namesReady = Promise.resolve();   // перевод названий (1.10.0)
let isCancelled = false;
let existingTracks = new Set();
let firebaseToken = null;
let firebaseUid = null;

// Карго-данные
let cargoOrdered = [];         // оригинальные треки в порядке файла xlsx
let cargoTracks = new Set();   // нормализованные треки (для быстрой проверки совпадений)
let cargoReady = false;        // файл загружен и распарсен
let cargoCompared = false;     // кнопка "Сравнить" нажата

// Поздние отправки: продавец отправил заказ позже, чем вы делали импорт за его даты.
const LOOKBACK_DAYS = 21;      // смотрим заказы на 3 недели раньше даты «С»
const DEEP_DAYS = 90;          // «Поискать за 3 месяца»
let lookbackPool = [];         // заказы из запаса до даты «С», которых нет в Piksta (берём только если они есть у карго)
let pddRange = { from: 0, to: 0, fetchFrom: 0 };
let deepDone = false;
const fmtDay = ts => new Date(ts * 1000).toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' });
async function getPending() {
  const { pdd_pending } = await chrome.storage.local.get('pdd_pending');
  const p = pdd_pending || {};
  const minTs = Date.now() / 1000 - DEEP_DAYS * 86400;
  for (const k of Object.keys(p)) if (!(p[k] > minTs)) delete p[k];
  return p;
}
function setStatusNote(html) {
  const el = document.getElementById('status-note');
  if (!el) return;
  el.innerHTML = html || '';
  el.style.display = html ? 'block' : 'none';
}

// ── СТРУКТУРА ТРЕКА ──────────────────────────────────────────────────────────
function makeTrackEntry(r) {
  return {
    t: r.track,
    w: '',
    img: r.thumb || '',
  };
}

function makeFirestoreTrackEntry(r) {
  const entry = makeTrackEntry(r);
  const fields = {};
  for (const [key, val] of Object.entries(entry)) {
    fields[key] = { stringValue: String(val) };
  }
  return { mapValue: { fields } };
}

// Для треков без PDD-данных (из карго, не из PDD)
function makeCargoOnlyEntry(track) {
  return {
    track,
    isNew: true,
    goods: '',
    price_cny: '',
    date: '',
    thumb: '',
    fromCargo: true,   // маркер: добавлен из файла карго
  };
}

// ── НОРМАЛИЗАЦИЯ ТРЕКА ───────────────────────────────────────────────────────
// Приводим к нижнему регистру и убираем пробелы/тире для сравнения.
// Хвост карго «-1-1» / «-1-1-» (номер места в многоместной посылке) отрезаем: «JDAP03082682595-1-1-» = «JDAP03082682595»
function normTrack(t) {
  return String(t).toLowerCase().replace(/\s/g, '').replace(/(-\d{1,3})+-?$/, '').replace(/-/g, '');
}

// ── СБРОС ────────────────────────────────────────────────────────────────────
function resetResults() {
  allResults = [];
  cargoOrdered = [];
  cargoTracks = new Set();
  cargoReady = false;
  cargoCompared = false;
  lookbackPool = []; deepDone = false;
  setStatusNote('');
  document.getElementById('cs-extra-note').style.display = 'none';
  document.getElementById('results').style.display = 'none';
  document.getElementById('action-buttons').style.display = 'none';
  document.getElementById('summary').style.display = 'none';
  document.getElementById('cargo-block').style.display = 'none';
  document.getElementById('cargo-block').classList.remove('has-file');
  document.getElementById('cargo-stats').style.display = 'none';
  document.getElementById('btn-cargo-compare').style.display = 'none';
  document.getElementById('cargo-filename').textContent = 'файл не выбран';
  document.getElementById('btn-reset').style.display = 'none';
  document.getElementById('error').style.display = 'none';
  setStatus('Нажмите Загрузить — можно переключать вкладки во время загрузки');
  [1,2,3].forEach(i => {
    const el = document.getElementById('step'+i);
    if (el) { el.style.background = '#ddd'; el.style.color = '#999'; }
  });
}

// ── ПЕРЕВОД ──────────────────────────────────────────────────────────────────
function detectLang(text) {
  return /[一-鿿]/.test(text) ? 'zh-CN' : 'en';
}

async function translateGoods(items) {
  const translations = {};
  const batchSize = 10;
  for (let i = 0; i < items.length; i += batchSize) {
    const batch = items.slice(i, i + batchSize);
    const promises = batch.map(async (r, j) => {
      const text = r.goods;
      if (!text) return;
      const lang = detectLang(text);
      const shortText = text.slice(0, 150);
      try {
        const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(shortText)}&langpair=${lang}|ru`;
        const resp = await fetch(url);
        const data = await resp.json();
        if (data.responseStatus === 200) {
          translations[i + j] = data.responseData.translatedText;
        }
      } catch(e) {}
    });
    await Promise.all(promises);
    if (i + batchSize < items.length) await new Promise(r => setTimeout(r, 200));
  }
  return translations;
}

// ── ПАРСИНГ XLSX КАРГО ───────────────────────────────────────────────────────
function parseCargoXlsx(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const wb = XLSX.read(e.target.result, { type: 'array' });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
        // Сохраняем ОРИГИНАЛЬНЫЙ порядок треков как в файле (массив, не Set)
        const orderedTracks = []; // оригинальные значения в порядке файла
        const seen = new Set();    // для дедупликации по нормализованному
        for (const row of rows) {
          for (const cell of row) {
            const val = String(cell).trim();
            // Трек-код: длина 8-30, только буквы/цифры/дефис, не дата (не ДД.ММ)
            if (val.length >= 8 && val.length <= 30 &&
                /^[a-zA-Z0-9\-]+$/.test(val) &&
                !/^\d{1,2}\.\d{1,2}/.test(val)) {
              const norm = normTrack(val);
              if (!seen.has(norm)) {
                seen.add(norm);
                orderedTracks.push(val); // оригинал (не нормализованный)
              }
            }
          }
        }
        resolve(orderedTracks);
      } catch(err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('Ошибка чтения файла'));
    reader.readAsArrayBuffer(file);
  });
}

// ── БЛОК КАРГО: инициализация обработчиков ───────────────────────────────────
function initCargoBlock() {
  const fileInput = document.getElementById('cargo-file-input');
  const pickBtn   = document.getElementById('btn-cargo-pick');
  const compareBtn = document.getElementById('btn-cargo-compare');
  const filenameEl = document.getElementById('cargo-filename');

  pickBtn.addEventListener('click', () => fileInput.click());

  fileInput.addEventListener('change', async () => {
    const file = fileInput.files[0];
    if (!file) return;
    filenameEl.textContent = '⏳ Читаю файл...';
    try {
      cargoOrdered = await parseCargoXlsx(file);           // оригиналы в порядке файла
      cargoTracks = new Set(cargoOrdered.map(t => normTrack(t))); // нормализованные для проверки
      filenameEl.textContent = `${file.name} (${cargoOrdered.length} треков)`;
      cargoReady = true;
      cargoCompared = false;
      document.getElementById('cargo-block').classList.add('has-file');
      compareBtn.style.display = 'block';
      document.getElementById('cargo-stats').style.display = 'none';
      deepDone = false;
    } catch(e) {
      filenameEl.textContent = '❌ Ошибка: ' + e.message;
      cargoReady = false;
    }
  });

  compareBtn.addEventListener('click', () => {
    if (!cargoReady) return;
    runCargoCompare();
  });
}

// ── СРАВНЕНИЕ: PDD + КАРГО ───────────────────────────────────────────────────
function runCargoCompare() {
  // Треки карго, которых нет в выбранных датах, но есть в запасе до даты «С» (продавец отправил поздно) — забираем
  if (lookbackPool.length) {
    const inAll = new Set(allResults.map(r => normTrack(r.track)));
    const rest = [];
    for (const r of lookbackPool) {
      if (cargoTracks.has(normTrack(r.track)) && !inAll.has(normTrack(r.track))) { r.late = true; allResults.push(r); }
      else rest.push(r);
    }
    lookbackPool = rest;
  }
  // PDD-треки (только новые — тех что уже в Piksta не добавляем)
  const pddNew = allResults.filter(r => r.isNew);
  const pddMap = new Map(); // normTrack -> result object
  for (const r of pddNew) {
    pddMap.set(normTrack(r.track), r);
  }

  let matchCount = 0;  // есть и в карго, и в PDD (с картинкой)
  let extraCount = 0;  // только в карго (без картинки)
  let skipCount  = 0;  // в PDD, но нет в карго → пропускаем

  for (const r of pddNew) {
    if (cargoTracks.has(normTrack(r.track))) {
      matchCount++;
    } else {
      skipCount++;
    }
  }

  // Треки только в карго (нет в PDD) — считаем по оригинальному списку
  const pddNormForCompare = new Set(pddNew.map(r => normTrack(r.track)));
  for (const origTrack of cargoOrdered) {
    if (!pddNormForCompare.has(normTrack(origTrack))) {
      extraCount++;
    }
  }

  const totalInPrikhod = matchCount + extraCount;

  // Обновляем UI
  document.getElementById('cs-total').textContent  = cargoOrdered.length;
  document.getElementById('cs-match').textContent  = matchCount;
  document.getElementById('cs-extra').textContent  = extraCount;
  document.getElementById('cs-skip').textContent   = skipCount;
  document.getElementById('cs-result-total').textContent = totalInPrikhod;
  document.getElementById('cargo-stats').style.display = 'block';

  cargoCompared = true;
  showExtraNote(extraCount);

  // Меняем текст кнопки "Проставить склады"
  const assignBtn = document.getElementById('btn-assign');
  assignBtn.textContent = `Распределить по клиентам → ${totalInPrikhod} ${plTracks(totalInPrikhod)}`;
}

// Пояснение под плитками карго: почему у части треков не будет картинки
function showExtraNote(extraCount) {
  const box = document.getElementById('cs-extra-note');
  const txt = document.getElementById('cs-extra-text');
  const btn = document.getElementById('btn-cargo-deep');
  if (!extraCount) { box.style.display = 'none'; return; }
  const range = pddRange.from ? `${fmtDay(pddRange.from)}–${fmtDay(Math.min(pddRange.to, Date.now() / 1000))}` : 'выбранные даты';
  txt.textContent = deepDone
    ? `${extraCount} ${plTracks(extraCount)} не ${extraCount === 1 ? 'нашёлся' : 'нашлись'} в ваших заказах Pinduoduo и за 3 месяца — скорее всего, ${extraCount === 1 ? 'заказан' : 'заказаны'} с другого аккаунта или на другой площадке. ${extraCount === 1 ? 'Он добавится' : 'Они добавятся'} в приход без картинки.`
    : `${extraCount} ${plTracks(extraCount)} есть у карго, но ${extraCount === 1 ? 'его' : 'их'} нет в ваших заказах Pinduoduo за ${range}. Так бывает, если заказ сделан раньше даты «С», продавец отправил поздно или заказано с другого аккаунта.`;
  btn.style.display = deepDone ? 'none' : 'block';
  box.style.display = 'block';
}
function plTracks(n) { const a = n % 10, b = n % 100; return (a === 1 && b !== 11) ? 'трек' : (a >= 2 && a <= 4 && (b < 12 || b > 14)) ? 'трека' : 'треков'; }

// «Поискать за 3 месяца»: ищем треки карго в старых заказах Pinduoduo и подтягиваем картинку и цену
async function deepSearchCargo() {
  const btn = document.getElementById('btn-cargo-deep');
  const inAll = new Set(allResults.filter(r => r.isNew).map(r => normTrack(r.track)));
  const want = new Set(cargoOrdered.map(normTrack).filter(t => !inAll.has(t)));
  if (!want.size) return;
  if (!srcLogged.pdd) { showError('Нет входа в Pinduoduo — войдите на yangkeduo.com в Chrome и повторите'); return; }
  btn.disabled = true; btn.textContent = '⏳ Ищу в заказах...';
  const progress = (msg) => { if (msg.type === 'PDD_PROGRESS') btn.textContent = `⏳ Ищу в заказах... стр. ${msg.page}`; };
  chrome.runtime.onMessage.addListener(progress);
  const from = Math.floor(Date.now() / 1000 - DEEP_DAYS * 86400);
  const response = await chrome.runtime.sendMessage({ type: 'FETCH_PDD_TRACKS', fromDate: from, toDate: pddRange.fetchFrom || pddRange.from });
  chrome.runtime.onMessage.removeListener(progress);
  btn.disabled = false; btn.textContent = '🔎 Поискать за 3 месяца';
  if (!response || !response.ok) { showError('Ошибка Pinduoduo: ' + (response && response.error) + '. Убедитесь, что вы вошли на yangkeduo.com'); return; }
  let found = 0;
  for (const r of response.results) {
    if (!want.has(normTrack(r.track))) continue;
    r.isNew = !existingTracks.has(normTrack(r.track));
    r.late = true;
    allResults.push(r); want.delete(normTrack(r.track)); found++;
  }
  deepDone = true;
  runCargoCompare();
  setStatus(found ? `✅ Нашли в старых заказах: ${found} — добавятся с картинкой и ценой` : 'В заказах за 3 месяца этих треков нет', found ? '#2a7a2a' : '#666');
}

// ── ФОРМИРУЕМ ИТОГОВЫЙ СПИСОК ДЛЯ ЭКРАНА СКЛАДОВ ────────────────────────────
function buildFinalTracks() {
  // Если карго НЕ загружен — новые PDD треки, но РАЗВЁРНУТЫЕ (старый вверху, новый внизу).
  // allResults идёт от новых к старым (background листает автоскроллом вниз) → reverse.
  if (!cargoReady || !cargoCompared) {
    const pddOnly = allResults.filter(r => r.isNew);
    const reversed = [];
    for (let i = pddOnly.length - 1; i >= 0; i--) reversed.push(pddOnly[i]);
    return reversed;
  }

  const pddNew = allResults.filter(r => r.isNew);
  // Карта нормализованный трек → PDD-объект (для проверки совпадений)
  const pddMap = new Map();
  for (const r of pddNew) pddMap.set(normTrack(r.track), r);

  // Множество нормализованных PDD-треков (чтобы знать каких из карго НЕТ в PDD)
  const pddNormSet = new Set(pddNew.map(r => normTrack(r.track)));

  const final = [];

  // ── БЛОК 1 (СВЕРХУ): PDD-треки, совпавшие с карго ──
  //    allResults идёт от НОВЫХ к старым (background листает автоскроллом вниз).
  //    Нам нужен СТАРЫЙ ВВЕРХУ → разворачиваем: идём с конца массива к началу.
  //    Так самый старый купленный товар окажется вверху, разбираем сверху вниз. С картинками.
  const pddMatched = pddNew.filter(r => cargoTracks.has(normTrack(r.track)));
  for (let i = pddMatched.length - 1; i >= 0; i--) {
    final.push(pddMatched[i]); // reverse: старый вверху, новый ниже
  }

  // ── БЛОК 2 (ВНИЗУ): треки только из карго, которых НЕТ в PDD ──
  //    (1688/Taobao, без картинок). Блоком в самом низу — разбираем последними.
  //    Порядок — как в файле xlsx.
  for (const origTrack of cargoOrdered) {
    if (!pddNormSet.has(normTrack(origTrack))) {
      final.push(makeCargoOnlyEntry(origTrack));
    }
  }

  return final;
}

// ── ЭКРАН СКЛАДОВ ────────────────────────────────────────────────────────────
async function openAssignPage() {
  const tracksToAssign = buildFinalTracks();
  const ab = document.getElementById('btn-assign'), abTxt = ab.textContent;
  if (tracksToAssign.some(r => (r.name === undefined && (r.goods || r.sku)) || pkSpecTodo(r))) {
    ab.textContent = '⏳ Перевожу названия...';
    await namesReady; await translateNames(tracksToAssign);
    ab.textContent = abTxt;
  }
  if (!tracksToAssign.length) {
    alert('Нет треков для импорта. Сначала загрузите треки и выберите файл карго.');
    return;
  }

  const shipments = await loadShipments();
  const choice = await showAssignShipmentDialog(shipments, tracksToAssign.length);
  if (!choice) return;

  let targetShipmentId = null;
  let targetShipmentName = '';

  if (choice.mode === 'new') {
    targetShipmentId = null;
    targetShipmentName = choice.name;
  } else {
    targetShipmentId = choice.id;
    targetShipmentName = choice.name;
  }

  await chrome.storage.local.set({
    assign_tracks: tracksToAssign,
    assign_shipment_id: targetShipmentId,
    assign_shipment_name: targetShipmentName,
    assign_mode: choice.mode,
    firebase_token: firebaseToken,
    firebase_uid: firebaseUid,
  });

  chrome.tabs.create({ url: chrome.runtime.getURL('assign.html') });
}

async function showAssignShipmentDialog(shipments, trackCount) {
  return new Promise(resolve => {
    const overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);z-index:1000;display:flex;align-items:center;justify-content:center;';

    const today = new Date().toLocaleDateString('ru-RU', {day:'2-digit',month:'2-digit',year:'2-digit'});
    const defaultName = `Отправка ${today}`;

    const weekDates = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      weekDates.push(d.toLocaleDateString('ru-RU', {day:'2-digit',month:'2-digit',year:'2-digit'}));
    }
    const todayShipment = shipments.find(s => weekDates.some(date => s.name.includes(date)));
    const startMode = todayShipment ? 'exist' : 'new';

    const dialog = document.createElement('div');
    dialog.style.cssText = 'background:#fff;border-radius:16px;padding:24px;width:90%;max-width:440px;box-shadow:0 8px 40px rgba(0,0,0,0.2);';
    dialog.innerHTML = `
      <div style="font-weight:700;font-size:16px;color:#1a1440;margin-bottom:16px">
        🏷️ Куда добавить ${trackCount} треков?
      </div>
      ${todayShipment ? `<div style="background:#f0fff4;border:1px solid #86efac;border-radius:8px;padding:10px 12px;font-size:13px;color:#166534;margin-bottom:14px;">
        📅 Найдена сегодняшняя партия: <b>${todayShipment.name}</b> (${todayShipment.trackCount} треков) — выбрана автоматически
      </div>` : ''}
      <div style="display:flex;gap:0;margin-bottom:16px;border:2px solid #6C4DB8;border-radius:10px;overflow:hidden;">
        <button id="dtab-new" style="flex:1;padding:10px;border:none;background:${startMode==='new'?'#6C4DB8':'#fff'};color:${startMode==='new'?'#fff':'#6C4DB8'};font-weight:600;font-size:13px;cursor:pointer;">Новая партия</button>
        <button id="dtab-exist" style="flex:1;padding:10px;border:none;background:${startMode==='exist'?'#6C4DB8':'#fff'};color:${startMode==='exist'?'#fff':'#6C4DB8'};font-weight:600;font-size:13px;cursor:pointer;">Существующая</button>
      </div>
      <div id="dpanel-new" style="display:${startMode==='new'?'block':'none'}">
        <label style="font-size:12px;color:#666;display:block;margin-bottom:6px">Название:</label>
        <input id="dshipment-name" type="text" value="${defaultName}" style="width:100%;border:1px solid #ddd;border-radius:8px;padding:8px 10px;font-size:14px;margin-bottom:8px;box-sizing:border-box;">
        <div id="dname-warn" style="display:none;background:#fff3cd;border:1px solid #ffc107;border-radius:8px;padding:8px 10px;font-size:12px;color:#856404;margin-bottom:10px;line-height:1.5;"></div>
      </div>
      <div id="dpanel-exist" style="display:${startMode==='exist'?'block':'none'}">
        <label style="font-size:12px;color:#666;display:block;margin-bottom:6px">Выберите партию:</label>
        <select id="dshipment-select" style="width:100%;border:1px solid #ddd;border-radius:8px;padding:8px 10px;font-size:13px;margin-bottom:14px;box-sizing:border-box;">
          ${shipments.map(s => `<option value="${s.id}" ${todayShipment && s.id===todayShipment.id?'selected':''}>${s.name} (${s.trackCount} треков)</option>`).join('')}
        </select>
      </div>
      <div style="display:flex;gap:8px;">
        <button id="dbtn-confirm" style="flex:1;background:#6C4DB8;color:#fff;border:none;border-radius:8px;padding:10px;font-size:14px;font-weight:600;cursor:pointer;">Далее → Клиенты</button>
        <button id="dbtn-cancel" style="flex:1;background:#fff;color:#666;border:2px solid #ddd;border-radius:8px;padding:10px;font-size:13px;cursor:pointer;">Отмена</button>
      </div>`;

    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    let mode = startMode;
    dialog.querySelector('#dtab-new').onclick = () => {
      mode = 'new';
      dialog.querySelector('#dtab-new').style.background = '#6C4DB8'; dialog.querySelector('#dtab-new').style.color = '#fff';
      dialog.querySelector('#dtab-exist').style.background = '#fff'; dialog.querySelector('#dtab-exist').style.color = '#6C4DB8';
      dialog.querySelector('#dpanel-new').style.display = 'block';
      dialog.querySelector('#dpanel-exist').style.display = 'none';
    };
    dialog.querySelector('#dtab-exist').onclick = () => {
      mode = 'exist';
      dialog.querySelector('#dtab-exist').style.background = '#6C4DB8'; dialog.querySelector('#dtab-exist').style.color = '#fff';
      dialog.querySelector('#dtab-new').style.background = '#fff'; dialog.querySelector('#dtab-new').style.color = '#6C4DB8';
      dialog.querySelector('#dpanel-exist').style.display = 'block';
      dialog.querySelector('#dpanel-new').style.display = 'none';
    };
    dialog.querySelector('#dbtn-cancel').onclick = () => { overlay.remove(); resolve(null); };
    dialog.querySelector('#dbtn-confirm').onclick = () => {
      let result;
      if (mode === 'new') {
        const nameVal = dialog.querySelector('#dshipment-name').value.trim() || defaultName;
        const duplicate = shipments.find(s => s.name.trim() === nameVal.trim());
        if (duplicate) {
          const warn = dialog.querySelector('#dname-warn');
          if (warn) {
            warn.style.display = 'block';
            warn.innerHTML = `⚠️ Партия с таким названием уже существует (${duplicate.trackCount} треков).<br>
              <span style="cursor:pointer;color:#6C4DB8;text-decoration:underline;" id="switch-to-exist">Добавить в неё →</span>`;
            warn.querySelector('#switch-to-exist').onclick = () => {
              dialog.querySelector('#dtab-exist').click();
              const sel = dialog.querySelector('#dshipment-select');
              for (let opt of sel.options) { if (opt.value === duplicate.id) { opt.selected = true; break; } }
            };
          }
          return;
        }
        result = { mode: 'new', name: nameVal };
      } else {
        const sel = dialog.querySelector('#dshipment-select');
        const cleanName = sel.selectedOptions[0].text.replace(/\s*\(\d+ треков\)\s*$/, '').trim();
        result = { mode: 'exist', id: sel.value, name: cleanName };
      }
      overlay.remove();
      resolve(result);
    };
  });
}

// ── ПАРТИИ FIREBASE ──────────────────────────────────────────────────────────
async function loadShipments() {
  const url = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT}/databases/(default)/documents/users/${firebaseUid}/shipments?orderBy=created%20desc`;
  const resp = await fetch(url, { headers: { 'Authorization': `Bearer ${firebaseToken}` } });
  if (!resp.ok) throw new Error('Ошибка загрузки партий: ' + resp.status);
  const data = await resp.json();
  const docs = data.documents || [];
  return docs.map(doc => {
    const id = doc.name.split('/').pop();
    const fields = doc.fields || {};
    const trackCount = fields.data?.arrayValue?.values?.length || 0;
    return { id, name: fields.name?.stringValue || 'Без названия', trackCount };
  });
}

// ── UI-УТИЛИТЫ ───────────────────────────────────────────────────────────────
// Дата по умолчанию — сегодня (локальная, без UTC-сдвига)
const d = new Date();
const localToday = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
document.getElementById('from-date').value = localToday;
document.getElementById('to-date').value = localToday;  // по умолчанию — сегодня

document.getElementById('btn-run').onclick = () => run();




document.getElementById('btn-assign').onclick = () => openAssignPage();
document.getElementById('btn-reset').onclick = () => resetResults();

// Инициализируем блок карго
initCargoBlock();

// ── ИСТОЧНИКИ (1.10.0): Pinduoduo, Taobao и 1688, вход проверяем по cookie в Chrome ──
const SRC = { pdd: { name: 'Pinduoduo', login: 'https://mobile.yangkeduo.com/login.html', site: 'yangkeduo.com' },
              tb:  { name: 'Taobao',    login: 'https://login.taobao.com/',              site: 'taobao.com' },
              '1688': { name: '1688',   login: 'https://login.1688.com/',                site: '1688.com' } };
const SRC_KEYS = ['pdd', 'tb', '1688'];
const SRC_MSG = { pdd: 'FETCH_PDD_TRACKS', tb: 'FETCH_TB_TRACKS', '1688': 'FETCH_1688_TRACKS' };
const SRC_SN = { tb: 'tb_', '1688': 'a1688_' };   // префикс номера заказа без трека; у Pinduoduo префикса нет
const srcOf = sn => SRC_KEYS.find(k => SRC_SN[k] && String(sn).startsWith(SRC_SN[k])) || 'pdd';
let srcLogged = { pdd: false, tb: false, '1688': false };
let srcWanted = { pdd: true, tb: true, '1688': true };
async function hasCookie(url, names) {
  for (const name of names) { try { const c = await chrome.cookies.get({ url, name }); if (c && c.value) return true; } catch (e) {} }
  return false;
}
async function checkLogins() {
  srcLogged.pdd = await hasCookie('https://mobile.yangkeduo.com/', ['PDDAccessToken', 'pdd_user_id']);
  srcLogged.tb  = await hasCookie('https://www.taobao.com/', ['unb', 'cookie17']) || await hasCookie('https://buyertrade.taobao.com/', ['unb', 'cookie17']);
  srcLogged['1688'] = await hasCookie('https://www.1688.com/', ['unb', '__cn_logon_id__']);
  paintSources();
}
function paintSources() {
  for (const k of SRC_KEYS) {
    const cb = document.getElementById('cb-' + k), st = document.getElementById('st-' + k), box = document.getElementById('src-' + k);
    cb.disabled = !srcLogged[k];
    cb.checked = srcLogged[k] && srcWanted[k];
    box.classList.toggle('on', cb.checked);
    if (srcLogged[k]) { st.className = 'ok'; st.textContent = '● вход есть'; }
    else { st.className = 'no'; st.innerHTML = `нет входа · <a href="#" data-login="${k}" style="color:inherit">войти →</a>`; }
  }
  const any = activeSources().length;
  const hint = document.getElementById('src-hint');
  if (!SRC_KEYS.some(k => srcLogged[k])) {
    hint.innerHTML = '<b style="color:#b45309">Импорт невозможен: вы не вошли в личный кабинет ни на одном маркетплейсе.</b> Войдите на Pinduoduo, Taobao или 1688 в этом Chrome — статус обновится сам.';
  } else if (!any) {
    hint.innerHTML = '<b style="color:#b45309">Отметьте хотя бы один маркетплейс.</b>';
  } else {
    hint.textContent = 'Достаточно один раз войти на сайт в Chrome — расширение само найдёт ваши заказы. Берём только отправленные, с трек-номером.';
  }
  const btn = document.getElementById('btn-run');
  if (btn.textContent.trim() === 'Загрузить') btn.disabled = !any;
}
function activeSources() { return SRC_KEYS.filter(k => srcLogged[k] && srcWanted[k]); }
for (const k of SRC_KEYS) {
  document.getElementById('cb-' + k).addEventListener('change', e => { srcWanted[k] = e.target.checked; chrome.storage.local.set({ import_src: srcWanted }); paintSources(); });
}
document.getElementById('srcBox').addEventListener('click', e => {
  const a = e.target.closest('[data-login]'); if (!a) return;
  e.preventDefault(); chrome.tabs.create({ url: SRC[a.dataset.login].login });
});
chrome.storage.local.get('import_src').then(({ import_src }) => { if (import_src) srcWanted = Object.assign(srcWanted, import_src); checkLogins(); });
setInterval(() => { if (!document.hidden) checkLogins(); }, 4000);   // вошли на сайте — статус обновится сам
window.addEventListener('focus', checkLogins);

document.getElementById('btn-cargo-deep').addEventListener('click', () => deepSearchCargo());

function setStatus(text, color) {
  const el = document.getElementById('status');
  el.textContent = text;
  el.style.color = color || '#666';
}

function showError(text) {
  const el = document.getElementById('error');
  el.textContent = text;
  el.style.display = 'block';
}

function hideError() {
  document.getElementById('error').style.display = 'none';
}

function setStep(n) {
  [1, 2, 3].forEach(i => {
    const el = document.getElementById('step' + i);
    if (!el) return;
    if (i < n)      { el.style.background = '#6C4DB8'; el.style.color = '#fff'; }
    else if (i === n) { el.style.background = '#F5A623'; el.style.color = '#fff'; }
    else            { el.style.background = '#ddd';    el.style.color = '#999'; }
  });
}

// ── FIREBASE AUTH ────────────────────────────────────────────────────────────
async function getFirebaseAuth() {
  setStep(1);
  setStatus('Шаг 1/3: проверяю авторизацию в Piksta...');
  const stored = await chrome.storage.local.get(['firebase_token', 'firebase_uid', 'firebase_expiry', 'firebase_email']);
  if (stored.firebase_token && stored.firebase_expiry > Date.now() + 60000) {
    firebaseToken = stored.firebase_token;
    firebaseUid = stored.firebase_uid;
    document.getElementById('user-email').textContent = stored.firebase_email || '';
    return true;
  }
  const tabs = await chrome.tabs.query({});
  const pikstaTab = tabs.find(t => t.url && t.url.includes('piksta.online'));
  if (!pikstaTab) { showError('Откройте piksta.online в браузере, войдите в аккаунт и попробуйте снова'); return false; }
  const results = await chrome.scripting.executeScript({
    target: { tabId: pikstaTab.id }, world: 'MAIN',
    func: async () => {
      try {
        if (typeof window.firebase === 'undefined') return { error: 'Firebase не найден на странице' };
        const user = window.firebase.auth().currentUser;
        if (!user) return { error: 'Пользователь не авторизован' };
        const token = await user.getIdToken(false);
        return { uid: user.uid, email: user.email, token };
      } catch(e) { return { error: e.message }; }
    }
  });
  const data = results[0]?.result;
  if (!data || data.error) { showError(data?.error || 'Не удалось получить токен. Обновите piksta.online и попробуйте снова'); return false; }
  firebaseToken = data.token;
  firebaseUid = data.uid;
  await chrome.storage.local.set({ firebase_token: firebaseToken, firebase_uid: firebaseUid, firebase_email: data.email, firebase_expiry: Date.now() + 50 * 60 * 1000 });
  document.getElementById('user-email').textContent = data.email || '';
  return true;
}

// ── ЗАГРУЗКА ТРЕКОВ PIKSTA ───────────────────────────────────────────────────
async function loadPikstaTracks() {
  setStep(2);
  setStatus('Шаг 2/3: загружаю треки из Piksta...');
  existingTracks = new Set();
  try {
    const url = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT}/databases/(default)/documents/users/${firebaseUid}/shipments`;
    const resp = await fetch(url, { headers: { 'Authorization': `Bearer ${firebaseToken}` } });
    if (!resp.ok) {
      if (resp.status === 401) { await chrome.storage.local.remove(['firebase_token','firebase_uid','firebase_expiry','firebase_email']); showError('Сессия истекла. Обновите piksta.online и попробуйте снова'); return false; }
      showError('Ошибка Firebase: ' + resp.status); return false;
    }
    const data = await resp.json();
    for (const shipment of data.documents || []) {
      for (const item of shipment.fields?.data?.arrayValue?.values || []) {
        const track = item.mapValue?.fields?.t?.stringValue;
        if (track) existingTracks.add(normTrack(track));
      }
    }
    setStatus(`Шаг 2/3: в Piksta ${existingTracks.size} треков`);
    return true;
  } catch(e) { showError('Ошибка Piksta: ' + e.message); return false; }
}

// ── ЗАГРУЗКА ИЗ МАРКЕТПЛЕЙСОВ (Pinduoduo и/или Taobao) ─────────────────────
let srcCounts = {};
async function loadPddTracks() {
  setStep(3);
  allResults = [];
  srcCounts = {};
  const fromDateStr = document.getElementById('from-date').value;
  const toDateStr   = document.getElementById('to-date').value;
  const fromDate = new Date(fromDateStr + 'T00:00:00').getTime() / 1000;  // начало дня "С"
  // "По дату" включительно: берём конец выбранного дня (23:59:59)
  const toDate = toDateStr ? (new Date(toDateStr + 'T23:59:59').getTime() / 1000) : Infinity;
  await checkLogins();
  const srcs = activeSources();
  if (!srcs.length) {
    showError(!SRC_KEYS.some(k => srcLogged[k])
      ? 'Импорт невозможен: вы не вошли в личный кабинет на маркетплейсе. Войдите на Pinduoduo, Taobao или 1688 в этом Chrome и нажмите «Загрузить» ещё раз.'
      : 'Отметьте хотя бы один маркетплейс');
    return false;
  }
  // Смотрим с запасом назад: заказы, которые продавец отправил поздно, иначе проскакивают между импортами
  const pending = await getPending();
  const pendTs = Object.values(pending);
  let fetchFrom = fromDate - LOOKBACK_DAYS * 86400;
  if (pendTs.length) fetchFrom = Math.min(fetchFrom, Math.min(...pendTs));
  fetchFrom = Math.max(fetchFrom, Math.floor(Date.now() / 1000 - DEEP_DAYS * 86400));
  pddRange = { from: fromDate, to: toDate, fetchFrom };
  const got = [], noTrackAll = [], errors = [];
  const counted = {};
  const progressListener = (msg) => {
    if (isCancelled) return;
    if (msg.type === 'PDD_PROGRESS') counted.pdd = `Pinduoduo: стр. ${msg.page}, треков ${msg.count}`;
    else if (msg.type === 'TB_PROGRESS') counted.tb = `Taobao: стр. ${msg.page}, треков ${msg.count}`;
    else return;
    setStatus('Шаг 3/3: ' + Object.values(counted).join(' · ') + ' — можно переключать вкладки');
  };
  chrome.runtime.onMessage.addListener(progressListener);
  setStatus('Шаг 3/3: загружаю заказы — ' + srcs.map(k => SRC[k].name).join(', ') + '...');
  await Promise.all(srcs.map(async k => {
    const response = await chrome.runtime.sendMessage({ type: SRC_MSG[k], fromDate: Math.min(fetchFrom, fromDate), toDate, rangeFrom: fromDate });
    if (!response || !response.ok) { errors.push(`${SRC[k].name}: ${(response && response.error) || 'нет ответа'}`); return; }
    for (const r of response.results) { r.src = r.src || k; got.push(r); }
    noTrackAll.push(...(response.noTrack || []));
    if (response.warn) errors.push(response.warn);
  }));
  chrome.runtime.onMessage.removeListener(progressListener);
  if (isCancelled) return false;
  if (errors.length && !got.length) { showError('Не удалось загрузить: ' + errors.join('; ')); return false; }
  got.sort((a, b) => (b.ts || 0) - (a.ts || 0));   // новые сверху, как раньше
  lookbackPool = [];
  let lateCount = 0;
  for (const r of got) {
    r.isNew = !existingTracks.has(normTrack(r.track));
    const wasPending = r.sn && pending[r.sn];
    if (r.sn) delete pending[r.sn];               // трек появился — больше не ждём
    if (r.ts >= fromDate) { allResults.push(r); srcCounts[r.src] = (srcCounts[r.src] || 0) + 1; continue; }
    if (!r.isNew) continue;                       // уже в Piksta
    if (wasPending) { r.late = true; allResults.push(r); srcCounts[r.src] = (srcCounts[r.src] || 0) + 1; lateCount++; }   // ждали этот заказ с прошлого импорта
    else lookbackPool.push(r);                    // возьмём, только если он есть в файле карго
  }
  // Заказы без трека (продавец ещё не отправил) — запоминаем до следующего импорта
  const waiting = noTrackAll.filter(o => o.ts >= fromDate);
  for (const o of noTrackAll) pending[o.sn] = o.ts;
  await chrome.storage.local.set({ pdd_pending: pending });
  const notes = [];
  const plO = n => { const a = n % 10, b = n % 100; return (a === 1 && b !== 11) ? 'заказ' : (a >= 2 && a <= 4 && (b < 12 || b > 14)) ? 'заказа' : 'заказов'; };
  if (lateCount) notes.push(`⏰ ${lateCount === 1 ? 'Подхвачен' : 'Подхвачено'} ${lateCount} ${plO(lateCount)}, ${lateCount === 1 ? 'который' : 'которые'} продавец отправил поздно`);
  for (const k of SRC_KEYS) {
    const w = waiting.filter(o => srcOf(o.sn) === k).length;
    if (w) notes.push(`${SRC[k].name}: ${w} ${plO(w)} ещё не ${w === 1 ? 'отправлен' : 'отправлены'} продавцом — подхватим в следующий раз`);
  }
  if (errors.length) notes.push('⚠️ ' + errors.join('; '));
  const offline = SRC_KEYS.filter(k => !srcLogged[k]).map(k => SRC[k].name);
  if (offline.length) notes.push(`${offline.join(', ')} не ${offline.length === 1 ? 'загружался' : 'загружались'} — нет входа`);
  setStatusNote(notes.join('<br>'));
  return true;
}

// ── НАЗВАНИЯ ТОВАРОВ (1.10.0): перевод на русский, коротко ───────────────────
const nameCache = {};
async function trRu(text) {
  text = String(text || '').trim(); if (!text) return '';
  if (!/[一-鿿]/.test(text) && !/[A-Za-z]{3}/.test(text.replace(/\b[A-Z0-9\-]{2,}\b/g, '').replace(/\d+\s?(cm|mm|kg|ml|g|m)\b/gi, ''))) return text;   // уже по-русски / только размеры и модели
  if (nameCache[text]) return nameCache[text];
  let out = '';
  try {
    const r = await fetch('https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ru&dt=t&q=' + encodeURIComponent(text));
    const j = await r.json(); out = (j[0] || []).map(x => x[0]).join('');
  } catch (e) {}
  if (!out) {
    try {
      const lp = /[一-鿿]/.test(text) ? 'zh-CN|ru' : 'en|ru';
      const r = await fetch('https://api.mymemory.translated.net/get?q=' + encodeURIComponent(text.slice(0, 150)) + '&langpair=' + lp);
      const j = await r.json(); if (j.responseStatus === 200) out = j.responseData.translatedText;
    } catch (e) {}
  }
  out = (out || '').trim();
  nameCache[text] = out;
  return out;
}
function shortName(t, max) {
  t = String(t || '').replace(/[【\[][^】\]]*[】\]]/g, ' ').replace(/\s+/g, ' ').trim();
  if (t.length <= max) return t;
  const cut = t.slice(0, max); const sp = cut.lastIndexOf(' ');
  return (sp > max * 0.6 ? cut.slice(0, sp) : cut).replace(/[,.;:\-–\s]+$/, '');
}

// Короткое название товара — общий словарь в pknames.js (тот же файл лежит на сайте /js/pknames.js — ДУБЛЬ, менять оба).
async function nameFor(r) {
  if (r.name !== undefined) return r.name;
  const orig = String(r.goods || '').trim();
  let n = '';
  if (orig) {
    const ru = await trRu(orig.slice(0, 120));
    n = pkNameShort(ru, orig);                          // 1.10.5: словарь + чистка мусора («2026», «новинка»…) + английские слова
    if (n === null) { n = pkNameFallback(ru || orig, 32); }
    if (n) n = n[0].toUpperCase() + n.slice(1);
  }
  // свойства товара (цвет, размер, комплектация) в название не пишем — только суть товара (06.11.2026);
  // свойства берём, лишь если у товара совсем нет названия
  if (!n && r.sku) {
    const sk0 = String(r.sku).replace(/[【\[][^】\]]*[】\]]/g, ' ').replace(/;/g, ', ').replace(/\s+/g, ' ').trim();
    const sk = shortName((await trRu(sk0)) || sk0, 26).toLowerCase();
    if (sk) n = sk;
  }
  r.name = n || '';
  return r.name;
}
// ── 1.10.8: СВОЙСТВА РАЗНОВИДНОСТИ ПО-РУССКИ (цвет, размер) ─────────────────────
// Строку площадки делим по «;» на части, мусор продавца («свяжитесь с поддержкой», «фото товара», «оптом») выкидываем.
// Всё, где есть цифры, и размерные буквы (ZBZ32-11, 5XL, 45X45CM, 73cm73/48(6-9M), S/M/L) не переводим: прячем перед переводом
// и возвращаем как были, только единицы по-русски (cm → см, kg → кг, 6-9M → 6–9 мес., 码 убираем). Остальное — через trRu.
const PK_SPEC_JUNK = /contact customer service|please contact|after (placing|ordering)|leave a (note|message)|product photos?|wholesale|hot sell|in[- ]stock items|manufacturer|联系客服|拍下|备注|现货|批发|厂家|热卖|实拍/i;
const PK_SPEC_TOK = /[^\s,，、;；()（）【】\[\]\u3000-\u9fff]*\d[^\s,，、;；()（）【】\[\]\u3000-\u9fff]*(?:斤|厘米|公斤|千克|个月|码)?|\b(?:X{0,4}[SML]|XXS|XS|X{1,4}L)\b/g;
function pkSpecUnits(t) {
  return String(t).replace(/码/g, '')
    .replace(/(\d)\s*(?:cm|CM|Cm|厘米)/g, '$1 см').replace(/(\d)\s*(?:mm|MM)/g, '$1 мм').replace(/(\d)\s*(?:kg|KG|Kg|公斤|千克)/g, '$1 кг').replace(/(\d)\s*斤/g, '$1 цзиней')
    .replace(/(\d+)\s*-\s*(\d+)\s*(?:M|个月)\b/g, '$1–$2 мес.').replace(/(\d+)\s*(?:个月)/g, '$1 мес.').replace(/(\d+ см)(\d)/g, '$1 · $2');
}
async function pkSpecRu(spec, tr) {
  const src = String(spec || '').trim(); if (!src) return '';
  let parts = src.split(/[;；|｜]/).map(x => x.trim()).filter(Boolean);
  const clean = parts.filter(p => !PK_SPEC_JUNK.test(p));
  parts = clean.length ? clean : parts.slice(0, 1);
  const out = [];
  for (let p of parts.slice(0, 3)) {
    p = p.replace(/码/g, '').replace(/[【\[]+/g, '(').replace(/[】\]]+/g, ')').replace(/（/g, '(').replace(/）/g, ')').replace(/\s+/g, ' ').trim();
    const toks = []; const masked = p.replace(PK_SPEC_TOK, m => { toks.push(m); return ' ⟦' + (toks.length - 1) + '⟧ '; });
    const back = s => s.replace(/⟦\s*(\d+)\s*⟧/g, (_, i) => pkSpecUnits(toks[+i] || ''));
    let ru;
    const words = masked.replace(/⟦\d+⟧/g, '').replace(/[\s.,·×\/\-–()+~:%*]/g, '');
    if (!words) ru = back(masked);                                   // одни размеры/артикулы — переводить нечего
    else {
      const t = await tr(masked.replace(/\s+/g, ' ').trim());
      if (t && toks.every((_, i) => new RegExp('⟦\\s*' + i + '\\s*⟧').test(t))) ru = back(t);
      else {                                                         // переводчик сломал метки — переводим куски между ними
        const res = [];
        for (const sg of masked.split(/(⟦\d+⟧)/)) { if (/^⟦\d+⟧$/.test(sg)) res.push(back(sg)); else if (sg.trim()) res.push((await tr(sg.trim())) || sg.trim()); }
        ru = res.join(' ');
      }
    }
    ru = ru.replace(/\s+([,.;:)])/g, '$1').replace(/\(\s+/g, '(').replace(/\(\)/g, '').replace(/\s+/g, ' ').trim().replace(/[.。]$/, '');
    if (ru.length > 56) { const cut = ru.slice(0, 56); const sp = cut.lastIndexOf(' '); ru = (sp > 34 ? cut.slice(0, sp) : cut).replace(/[,.;:\-–\s(]+$/, '') + '…'; }
    if (ru) out.push(ru[0].toUpperCase() + ru.slice(1));
  }
  return out.join(' · ');
}

const pkSpecTodo = r => Array.isArray(r.v) && r.v.some(x => x.s && x.ru === undefined);
async function specsFor(r) {   // 1.10.8: свойства каждой разновидности по-русски, оригинал остаётся в x.s
  if (!Array.isArray(r.v)) return;
  for (const x of r.v) if (x.s && x.ru === undefined) { try { x.ru = await pkSpecRu(x.s, trRu); } catch (e) { x.ru = ''; } }
}
async function translateNames(list, onEach) {
  const todo = list.filter(r => (r.name === undefined && (r.goods || r.sku)) || pkSpecTodo(r));
  for (let i = 0; i < todo.length; i += 6) {
    await Promise.all(todo.slice(i, i + 6).map(async r => { await nameFor(r); await specsFor(r); onEach && onEach(r); }));
  }
}

// ── СПИСОК РЕЗУЛЬТАТА (с фото, источником и названием) ──────────────────────
function escH(s) { return String(s || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
function rowHtml(r, i) {
  const badge = r.src === 'tb' ? '<span class="bdg tb">TAOBAO</span>' : r.src === '1688' ? '<span class="bdg a1688">1688</span>' : '<span class="bdg pdd">PDD</span>';
  const img = r.thumb ? `<img src="${escH(r.thumb)}" loading="lazy" referrerpolicy="no-referrer">` : '<div class="noimg"></div>';
  const nm = r.name ? `<div class="g">${escH(r.name)}</div><div class="sk">${escH((r.goods || '').slice(0, 40))}</div>` : `<div class="g" style="font-weight:400;color:#555">${escH((r.goods || '').slice(0, 45))}</div>${r.sku ? `<div class="sk">${escH(r.sku)}</div>` : ''}`;
  return `<div class="res-row" data-i="${i}">${img}<div style="min-width:0"><div class="t">${escH(r.track)}${badge}</div>${nm}${r.late ? '<div class="late">⏰ отправлен поздно</div>' : ''}</div><div class="pr">¥${escH(r.price_cny)}${(r.qty || 1) > 1 ? ' ×' + r.qty : ''}<small>${escH((r.date || '').slice(5).split('-').reverse().join('.'))}</small></div></div>`;
}
function renderResultsList() {
  const el = document.getElementById('results');
  el.style.display = 'block';
  const list = allResults.filter(r => r.isNew);
  el.innerHTML = list.length ? list.map(rowHtml).join('') : '<div style="padding:10px 0;color:#666">Новых треков нет — все уже есть в Piksta</div>';
  return list;
}

// ── ГЛАВНАЯ ФУНКЦИЯ ──────────────────────────────────────────────────────────
async function run() {
  hideError();
  allResults = [];
  cargoOrdered = [];
  cargoTracks = new Set();
  cargoReady = false;
  cargoCompared = false;
  document.getElementById('results').style.display = 'none';
  document.getElementById('action-buttons').style.display = 'none';
  document.getElementById('summary').style.display = 'none';
  document.getElementById('cargo-block').style.display = 'none';
  document.getElementById('cargo-stats').style.display = 'none';
  lookbackPool = []; deepDone = false;
  setStatusNote('');
  document.getElementById('cs-extra-note').style.display = 'none';

  const btn = document.getElementById('btn-run');
  isCancelled = false;
  btn.textContent = '⏹ Стоп';
  btn.style.background = '#c00';
  btn.onclick = () => { isCancelled = true; resetResults(); btn.textContent = 'Загрузить'; btn.style.background = ''; btn.onclick = () => run(); };

  try {
    if (!await getFirebaseAuth()) { btn.textContent = 'Загрузить'; btn.style.background = ''; btn.onclick = () => run(); return; }
    if (!await loadPikstaTracks()) { btn.textContent = 'Загрузить'; btn.style.background = ''; btn.onclick = () => run(); return; }
    if (!await loadPddTracks()) { btn.textContent = 'Загрузить'; btn.style.background = ''; btn.onclick = () => run(); return; }

    const newCount   = allResults.filter(r => r.isNew).length;
    const totalCount = allResults.length;

    const per = SRC_KEYS.filter(k => srcCounts[k] !== undefined || activeSources().includes(k)).map(k => `${SRC[k].name} — ${srcCounts[k] || 0}`).join(', ');
    setStatus(`✅ Готово: ${per} ${plTracks(totalCount)}. Можно сверить с файлом карго.`, '#2a7a2a');

    document.getElementById('summary').style.display = 'block';
    document.getElementById('count-total').textContent    = totalCount;
    document.getElementById('count-new').textContent      = newCount;
    document.getElementById('count-existing').textContent = totalCount - newCount;

    const newTracks = renderResultsList();
    // названия переводим в фоне и сразу обновляем строки
    namesReady = translateNames(newTracks, r => {
      const i = newTracks.indexOf(r); const el = document.querySelector(`#results .res-row[data-i="${i}"]`);
      if (el) el.outerHTML = rowHtml(r, i);
    });

    // Показываем блок карго
    document.getElementById('cargo-block').style.display = 'block';
    document.getElementById('cargo-block').classList.remove('has-file');
    document.getElementById('cargo-filename').textContent = 'файл не выбран';
    document.getElementById('btn-cargo-compare').style.display = 'none';

    document.getElementById('action-buttons').style.display = 'flex';
    document.getElementById('btn-reset').style.display = 'block';

    // Сброс текста кнопки склада
    document.getElementById('btn-assign').textContent = 'Распределить по клиентам →';

  } catch(e) {
    showError('Ошибка: ' + e.message);
  }

  btn.textContent = 'Загрузить';
  btn.style.background = '';
  btn.onclick = () => run();
}

// ── КОПИРОВАНИЕ И ЭКСПОРТ ────────────────────────────────────────────────────
async function copyTracks() {
  const text = allResults.map(r => r.track).join('\n');
  await doCopy(text, 'btn-copy');
}

async function copyNewTracks() {
  const text = allResults.filter(r => r.isNew).map(r => r.track).join('\n');
  await doCopy(text, 'btn-copy-new');
}

async function doCopy(text, btnId) {
  try {
    await navigator.clipboard.writeText(text);
    const btn = document.getElementById(btnId);
    const orig = btn.textContent;
    btn.textContent = '✅ Скопировано!';
    setTimeout(() => btn.textContent = orig, 2000);
  } catch(e) { alert(text); }
}

async function downloadCSV(onlyNew = false) {
  const data = onlyNew ? allResults.filter(r => r.isNew) : allResults;
  const suffix = onlyNew ? '_новые' : '';
  const btnId = onlyNew ? 'btn-csv-new' : 'btn-csv';
  const btn = document.getElementById(btnId);
  const origText = btn.textContent;
  btn.textContent = '⏳ Перевожу...';
  btn.disabled = true;
  setStatus(`Перевожу ${data.length} названий на русский...`);
  const translations = await translateGoods(data);
  const bom = '\uFEFF';
  const header = 'Трек-номер,Клиент,Описание (RU),Описание оригинал,Цена (CNY),Дата заказа';
  const rows = data.map((r, i) => {
    const ru   = (translations[i] || r.goods || '').replace(/"/g, '""');
    const orig = (r.goods || '').replace(/"/g, '""');
    return `${r.track},"","${ru}","${orig}",${r.price_cny},${r.date}`;
  });
  const csv = bom + [header, ...rows].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `piksta_pdd_${new Date().toISOString().slice(0,10)}${suffix}.csv`;
  a.click();
  URL.revokeObjectURL(url);
  btn.textContent = origText;
  btn.disabled = false;
  setStatus('✅ Готово!', '#2a7a2a');
}

// ── СЛУШАЕМ ЗАВЕРШЕНИЕ ИМПОРТА ───────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type !== 'IMPORT_DONE') return;
  const overlay = document.createElement('div');
  overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.75);z-index:9999;display:flex;align-items:center;justify-content:center;';
  const box = document.createElement('div');
  box.style.cssText = 'background:#fff;border-radius:16px;padding:32px;text-align:center;max-width:360px;width:90%;box-shadow:0 8px 40px rgba(0,0,0,0.3);';
  box.innerHTML = `
    <div style="font-size:48px;margin-bottom:12px">✅</div>
    <div style="font-weight:700;font-size:18px;color:#1a1440;margin-bottom:8px">Импорт завершён!</div>
    <div style="font-size:13px;color:#666;margin-bottom:20px">Партия <b>${msg.shipmentName || ''}</b> сохранена в Piksta с клиентами.</div>
    <button id="btn-close-import" style="width:100%;background:#c00;color:#fff;border:none;border-radius:8px;padding:12px;font-size:14px;font-weight:600;cursor:pointer;">✕ Закрыть эту вкладку</button>`;
  overlay.appendChild(box);
  document.body.appendChild(overlay);
  document.getElementById('btn-close-import').addEventListener('click', () => window.close());
});
