const API_URL = 'https://mobile.yangkeduo.com/proxy/api/api/aristotle/order_list_v4';
const FIREBASE_PROJECT = 'parcel-scanner-90427';

let allResults = [];
let isCancelled = false;
let existingTracks = new Set();
let firebaseToken = null;
let firebaseUid = null;

// Карго-данные
let cargoOrdered = [];         // оригинальные треки в порядке файла xlsx
let cargoTracks = new Set();   // нормализованные треки (для быстрой проверки совпадений)
let cargoReady = false;        // файл загружен и распарсен
let cargoCompared = false;     // кнопка "Сравнить" нажата

// ── СТРУКТУРА ТРЕКА ──────────────────────────────────────────────────────────
function makeTrackEntry(r) {
  return {
    t: r.track,
    w: '',
    img: r.thumb || '',
  };
}

function makeFirestoreTrackEntry(r) {
  const entry = makeTrackEntry(r);
  const fields = {};
  for (const [key, val] of Object.entries(entry)) {
    fields[key] = { stringValue: String(val) };
  }
  return { mapValue: { fields } };
}

// Для треков без PDD-данных (из карго, не из PDD)
function makeCargoOnlyEntry(track) {
  return {
    track,
    isNew: true,
    goods: '',
    price_cny: '',
    date: '',
    thumb: '',
    fromCargo: true,   // маркер: добавлен из файла карго
  };
}

// ── НОРМАЛИЗАЦИЯ ТРЕКА ───────────────────────────────────────────────────────
// Приводим к нижнему регистру и убираем пробелы/тире для сравнения
function normTrack(t) {
  return String(t).toLowerCase().replace(/[\s\-]/g, '');
}

// ── СБРОС ────────────────────────────────────────────────────────────────────
function resetResults() {
  allResults = [];
  cargoOrdered = [];
  cargoTracks = new Set();
  cargoReady = false;
  cargoCompared = false;
  document.getElementById('results').style.display = 'none';
  document.getElementById('action-buttons').style.display = 'none';
  document.getElementById('summary').style.display = 'none';
  document.getElementById('cargo-block').style.display = 'none';
  document.getElementById('cargo-block').classList.remove('has-file');
  document.getElementById('cargo-stats').style.display = 'none';
  document.getElementById('btn-cargo-compare').style.display = 'none';
  document.getElementById('cargo-filename').textContent = 'файл не выбран';
  document.getElementById('btn-reset').style.display = 'none';
  document.getElementById('error').style.display = 'none';
  setStatus('Нажмите Загрузить — можно переключать вкладки во время загрузки');
  [1,2,3].forEach(i => {
    const el = document.getElementById('step'+i);
    if (el) { el.style.background = '#ddd'; el.style.color = '#999'; }
  });
}

// ── ПЕРЕВОД ──────────────────────────────────────────────────────────────────
function detectLang(text) {
  return /[一-鿿]/.test(text) ? 'zh-CN' : 'en';
}

async function translateGoods(items) {
  const translations = {};
  const batchSize = 10;
  for (let i = 0; i < items.length; i += batchSize) {
    const batch = items.slice(i, i + batchSize);
    const promises = batch.map(async (r, j) => {
      const text = r.goods;
      if (!text) return;
      const lang = detectLang(text);
      const shortText = text.slice(0, 150);
      try {
        const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(shortText)}&langpair=${lang}|ru`;
        const resp = await fetch(url);
        const data = await resp.json();
        if (data.responseStatus === 200) {
          translations[i + j] = data.responseData.translatedText;
        }
      } catch(e) {}
    });
    await Promise.all(promises);
    if (i + batchSize < items.length) await new Promise(r => setTimeout(r, 200));
  }
  return translations;
}

// ── ПАРСИНГ XLSX КАРГО ───────────────────────────────────────────────────────
function parseCargoXlsx(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const wb = XLSX.read(e.target.result, { type: 'array' });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
        // Сохраняем ОРИГИНАЛЬНЫЙ порядок треков как в файле (массив, не Set)
        const orderedTracks = []; // оригинальные значения в порядке файла
        const seen = new Set();    // для дедупликации по нормализованному
        for (const row of rows) {
          for (const cell of row) {
            const val = String(cell).trim();
            // Трек-код: длина 8-30, только буквы/цифры/дефис, не дата (не ДД.ММ)
            if (val.length >= 8 && val.length <= 30 &&
                /^[a-zA-Z0-9\-]+$/.test(val) &&
                !/^\d{1,2}\.\d{1,2}/.test(val)) {
              const norm = normTrack(val);
              if (!seen.has(norm)) {
                seen.add(norm);
                orderedTracks.push(val); // оригинал (не нормализованный)
              }
            }
          }
        }
        resolve(orderedTracks);
      } catch(err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('Ошибка чтения файла'));
    reader.readAsArrayBuffer(file);
  });
}

// ── БЛОК КАРГО: инициализация обработчиков ───────────────────────────────────
function initCargoBlock() {
  const fileInput = document.getElementById('cargo-file-input');
  const pickBtn   = document.getElementById('btn-cargo-pick');
  const compareBtn = document.getElementById('btn-cargo-compare');
  const filenameEl = document.getElementById('cargo-filename');

  pickBtn.addEventListener('click', () => fileInput.click());

  fileInput.addEventListener('change', async () => {
    const file = fileInput.files[0];
    if (!file) return;
    filenameEl.textContent = '⏳ Читаю файл...';
    try {
      cargoOrdered = await parseCargoXlsx(file);           // оригиналы в порядке файла
      cargoTracks = new Set(cargoOrdered.map(t => normTrack(t))); // нормализованные для проверки
      filenameEl.textContent = `${file.name} (${cargoOrdered.length} треков)`;
      cargoReady = true;
      cargoCompared = false;
      document.getElementById('cargo-block').classList.add('has-file');
      compareBtn.style.display = 'block';
      document.getElementById('cargo-stats').style.display = 'none';
    } catch(e) {
      filenameEl.textContent = '❌ Ошибка: ' + e.message;
      cargoReady = false;
    }
  });

  compareBtn.addEventListener('click', () => {
    if (!cargoReady) return;
    runCargoCompare();
  });
}

// ── СРАВНЕНИЕ: PDD + КАРГО ───────────────────────────────────────────────────
function runCargoCompare() {
  // PDD-треки (только новые — тех что уже в Piksta не добавляем)
  const pddNew = allResults.filter(r => r.isNew);
  const pddMap = new Map(); // normTrack -> result object
  for (const r of pddNew) {
    pddMap.set(normTrack(r.track), r);
  }

  let matchCount = 0;  // есть и в карго, и в PDD (с картинкой)
  let extraCount = 0;  // только в карго (без картинки)
  let skipCount  = 0;  // в PDD, но нет в карго → пропускаем

  for (const r of pddNew) {
    if (cargoTracks.has(normTrack(r.track))) {
      matchCount++;
    } else {
      skipCount++;
    }
  }

  // Треки только в карго (нет в PDD) — считаем по оригинальному списку
  const pddNormForCompare = new Set(pddNew.map(r => normTrack(r.track)));
  for (const origTrack of cargoOrdered) {
    if (!pddNormForCompare.has(normTrack(origTrack))) {
      extraCount++;
    }
  }

  const totalInPrikhod = matchCount + extraCount;

  // Обновляем UI
  document.getElementById('cs-total').textContent  = cargoOrdered.length;
  document.getElementById('cs-match').textContent  = matchCount;
  document.getElementById('cs-extra').textContent  = extraCount;
  document.getElementById('cs-skip').textContent   = skipCount;
  document.getElementById('cs-result-total').textContent = totalInPrikhod;
  document.getElementById('cargo-stats').style.display = 'block';

  cargoCompared = true;

  // Меняем текст кнопки "Проставить склады"
  const assignBtn = document.getElementById('btn-assign');
  assignBtn.textContent = `🏷️ Проставить склады → ${totalInPrikhod} треков в приход`;
}

// ── ФОРМИРУЕМ ИТОГОВЫЙ СПИСОК ДЛЯ ЭКРАНА СКЛАДОВ ────────────────────────────
function buildFinalTracks() {
  // Если карго НЕ загружен — новые PDD треки, но РАЗВЁРНУТЫЕ (старый вверху, новый внизу).
  // allResults идёт от новых к старым (background листает автоскроллом вниз) → reverse.
  if (!cargoReady || !cargoCompared) {
    const pddOnly = allResults.filter(r => r.isNew);
    const reversed = [];
    for (let i = pddOnly.length - 1; i >= 0; i--) reversed.push(pddOnly[i]);
    return reversed;
  }

  const pddNew = allResults.filter(r => r.isNew);
  // Карта нормализованный трек → PDD-объект (для проверки совпадений)
  const pddMap = new Map();
  for (const r of pddNew) pddMap.set(normTrack(r.track), r);

  // Множество нормализованных PDD-треков (чтобы знать каких из карго НЕТ в PDD)
  const pddNormSet = new Set(pddNew.map(r => normTrack(r.track)));

  const final = [];

  // ── БЛОК 1 (СВЕРХУ): PDD-треки, совпавшие с карго ──
  //    allResults идёт от НОВЫХ к старым (background листает автоскроллом вниз).
  //    Нам нужен СТАРЫЙ ВВЕРХУ → разворачиваем: идём с конца массива к началу.
  //    Так самый старый купленный товар окажется вверху, разбираем сверху вниз. С картинками.
  const pddMatched = pddNew.filter(r => cargoTracks.has(normTrack(r.track)));
  for (let i = pddMatched.length - 1; i >= 0; i--) {
    final.push(pddMatched[i]); // reverse: старый вверху, новый ниже
  }

  // ── БЛОК 2 (ВНИЗУ): треки только из карго, которых НЕТ в PDD ──
  //    (1688/Taobao, без картинок). Блоком в самом низу — разбираем последними.
  //    Порядок — как в файле xlsx.
  for (const origTrack of cargoOrdered) {
    if (!pddNormSet.has(normTrack(origTrack))) {
      final.push(makeCargoOnlyEntry(origTrack));
    }
  }

  return final;
}

// ── ЭКРАН СКЛАДОВ ────────────────────────────────────────────────────────────
async function openAssignPage() {
  const tracksToAssign = buildFinalTracks();
  if (!tracksToAssign.length) {
    alert('Нет треков для импорта. Сначала загрузите треки и выберите файл карго.');
    return;
  }

  const shipments = await loadShipments();
  const choice = await showAssignShipmentDialog(shipments, tracksToAssign.length);
  if (!choice) return;

  let targetShipmentId = null;
  let targetShipmentName = '';

  if (choice.mode === 'new') {
    targetShipmentId = null;
    targetShipmentName = choice.name;
  } else {
    targetShipmentId = choice.id;
    targetShipmentName = choice.name;
  }

  await chrome.storage.local.set({
    assign_tracks: tracksToAssign,
    assign_shipment_id: targetShipmentId,
    assign_shipment_name: targetShipmentName,
    assign_mode: choice.mode,
    firebase_token: firebaseToken,
    firebase_uid: firebaseUid,
  });

  chrome.tabs.create({ url: chrome.runtime.getURL('assign.html') });
}

async function showAssignShipmentDialog(shipments, trackCount) {
  return new Promise(resolve => {
    const overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);z-index:1000;display:flex;align-items:center;justify-content:center;';

    const today = new Date().toLocaleDateString('ru-RU', {day:'2-digit',month:'2-digit',year:'2-digit'});
    const defaultName = `Отправка ${today}`;

    const weekDates = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      weekDates.push(d.toLocaleDateString('ru-RU', {day:'2-digit',month:'2-digit',year:'2-digit'}));
    }
    const todayShipment = shipments.find(s => weekDates.some(date => s.name.includes(date)));
    const startMode = todayShipment ? 'exist' : 'new';

    const dialog = document.createElement('div');
    dialog.style.cssText = 'background:#fff;border-radius:16px;padding:24px;width:90%;max-width:440px;box-shadow:0 8px 40px rgba(0,0,0,0.2);';
    dialog.innerHTML = `
      <div style="font-weight:700;font-size:16px;color:#1a1440;margin-bottom:16px">
        🏷️ Куда добавить ${trackCount} треков?
      </div>
      ${todayShipment ? `<div style="background:#f0fff4;border:1px solid #86efac;border-radius:8px;padding:10px 12px;font-size:13px;color:#166534;margin-bottom:14px;">
        📅 Найдена сегодняшняя партия: <b>${todayShipment.name}</b> (${todayShipment.trackCount} треков) — выбрана автоматически
      </div>` : ''}
      <div style="display:flex;gap:0;margin-bottom:16px;border:2px solid #6C4DB8;border-radius:10px;overflow:hidden;">
        <button id="dtab-new" style="flex:1;padding:10px;border:none;background:${startMode==='new'?'#6C4DB8':'#fff'};color:${startMode==='new'?'#fff':'#6C4DB8'};font-weight:600;font-size:13px;cursor:pointer;">Новая партия</button>
        <button id="dtab-exist" style="flex:1;padding:10px;border:none;background:${startMode==='exist'?'#6C4DB8':'#fff'};color:${startMode==='exist'?'#fff':'#6C4DB8'};font-weight:600;font-size:13px;cursor:pointer;">Существующая</button>
      </div>
      <div id="dpanel-new" style="display:${startMode==='new'?'block':'none'}">
        <label style="font-size:12px;color:#666;display:block;margin-bottom:6px">Название:</label>
        <input id="dshipment-name" type="text" value="${defaultName}" style="width:100%;border:1px solid #ddd;border-radius:8px;padding:8px 10px;font-size:14px;margin-bottom:8px;box-sizing:border-box;">
        <div id="dname-warn" style="display:none;background:#fff3cd;border:1px solid #ffc107;border-radius:8px;padding:8px 10px;font-size:12px;color:#856404;margin-bottom:10px;line-height:1.5;"></div>
      </div>
      <div id="dpanel-exist" style="display:${startMode==='exist'?'block':'none'}">
        <label style="font-size:12px;color:#666;display:block;margin-bottom:6px">Выберите партию:</label>
        <select id="dshipment-select" style="width:100%;border:1px solid #ddd;border-radius:8px;padding:8px 10px;font-size:13px;margin-bottom:14px;box-sizing:border-box;">
          ${shipments.map(s => `<option value="${s.id}" ${todayShipment && s.id===todayShipment.id?'selected':''}>${s.name} (${s.trackCount} треков)</option>`).join('')}
        </select>
      </div>
      <div style="display:flex;gap:8px;">
        <button id="dbtn-confirm" style="flex:1;background:#6C4DB8;color:#fff;border:none;border-radius:8px;padding:10px;font-size:14px;font-weight:600;cursor:pointer;">Далее → Склады</button>
        <button id="dbtn-cancel" style="flex:1;background:#fff;color:#666;border:2px solid #ddd;border-radius:8px;padding:10px;font-size:13px;cursor:pointer;">Отмена</button>
      </div>`;

    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    let mode = startMode;
    dialog.querySelector('#dtab-new').onclick = () => {
      mode = 'new';
      dialog.querySelector('#dtab-new').style.background = '#6C4DB8'; dialog.querySelector('#dtab-new').style.color = '#fff';
      dialog.querySelector('#dtab-exist').style.background = '#fff'; dialog.querySelector('#dtab-exist').style.color = '#6C4DB8';
      dialog.querySelector('#dpanel-new').style.display = 'block';
      dialog.querySelector('#dpanel-exist').style.display = 'none';
    };
    dialog.querySelector('#dtab-exist').onclick = () => {
      mode = 'exist';
      dialog.querySelector('#dtab-exist').style.background = '#6C4DB8'; dialog.querySelector('#dtab-exist').style.color = '#fff';
      dialog.querySelector('#dtab-new').style.background = '#fff'; dialog.querySelector('#dtab-new').style.color = '#6C4DB8';
      dialog.querySelector('#dpanel-exist').style.display = 'block';
      dialog.querySelector('#dpanel-new').style.display = 'none';
    };
    dialog.querySelector('#dbtn-cancel').onclick = () => { overlay.remove(); resolve(null); };
    dialog.querySelector('#dbtn-confirm').onclick = () => {
      let result;
      if (mode === 'new') {
        const nameVal = dialog.querySelector('#dshipment-name').value.trim() || defaultName;
        const duplicate = shipments.find(s => s.name.trim() === nameVal.trim());
        if (duplicate) {
          const warn = dialog.querySelector('#dname-warn');
          if (warn) {
            warn.style.display = 'block';
            warn.innerHTML = `⚠️ Партия с таким названием уже существует (${duplicate.trackCount} треков).<br>
              <span style="cursor:pointer;color:#6C4DB8;text-decoration:underline;" id="switch-to-exist">Добавить в неё →</span>`;
            warn.querySelector('#switch-to-exist').onclick = () => {
              dialog.querySelector('#dtab-exist').click();
              const sel = dialog.querySelector('#dshipment-select');
              for (let opt of sel.options) { if (opt.value === duplicate.id) { opt.selected = true; break; } }
            };
          }
          return;
        }
        result = { mode: 'new', name: nameVal };
      } else {
        const sel = dialog.querySelector('#dshipment-select');
        const cleanName = sel.selectedOptions[0].text.replace(/\s*\(\d+ треков\)\s*$/, '').trim();
        result = { mode: 'exist', id: sel.value, name: cleanName };
      }
      overlay.remove();
      resolve(result);
    };
  });
}

// ── ПАРТИИ FIREBASE ──────────────────────────────────────────────────────────
async function loadShipments() {
  const url = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT}/databases/(default)/documents/users/${firebaseUid}/shipments?orderBy=created%20desc`;
  const resp = await fetch(url, { headers: { 'Authorization': `Bearer ${firebaseToken}` } });
  if (!resp.ok) throw new Error('Ошибка загрузки партий: ' + resp.status);
  const data = await resp.json();
  const docs = data.documents || [];
  return docs.map(doc => {
    const id = doc.name.split('/').pop();
    const fields = doc.fields || {};
    const trackCount = fields.data?.arrayValue?.values?.length || 0;
    return { id, name: fields.name?.stringValue || 'Без названия', trackCount };
  });
}

// ── UI-УТИЛИТЫ ───────────────────────────────────────────────────────────────
// Дата по умолчанию — сегодня (локальная, без UTC-сдвига)
const d = new Date();
const localToday = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
document.getElementById('from-date').value = localToday;
document.getElementById('to-date').value = localToday;  // по умолчанию — сегодня

document.getElementById('btn-run').onclick = () => run();
document.getElementById('btn-copy').onclick = copyTracks;
document.getElementById('btn-copy-new').onclick = copyNewTracks;
document.getElementById('btn-csv').onclick = async () => downloadCSV(false);
document.getElementById('btn-csv-new').onclick = async () => downloadCSV(true);
document.getElementById('btn-assign').onclick = () => openAssignPage();
document.getElementById('btn-reset').onclick = () => resetResults();

// Инициализируем блок карго
initCargoBlock();

function setStatus(text, color) {
  const el = document.getElementById('status');
  el.textContent = text;
  el.style.color = color || '#666';
}

function showError(text) {
  const el = document.getElementById('error');
  el.textContent = text;
  el.style.display = 'block';
}

function hideError() {
  document.getElementById('error').style.display = 'none';
}

function setStep(n) {
  [1, 2, 3].forEach(i => {
    const el = document.getElementById('step' + i);
    if (!el) return;
    if (i < n)      { el.style.background = '#6C4DB8'; el.style.color = '#fff'; }
    else if (i === n) { el.style.background = '#F5A623'; el.style.color = '#fff'; }
    else            { el.style.background = '#ddd';    el.style.color = '#999'; }
  });
}

// ── FIREBASE AUTH ────────────────────────────────────────────────────────────
async function getFirebaseAuth() {
  setStep(1);
  setStatus('Шаг 1/3: проверяю авторизацию в Piksta...');
  const stored = await chrome.storage.local.get(['firebase_token', 'firebase_uid', 'firebase_expiry', 'firebase_email']);
  if (stored.firebase_token && stored.firebase_expiry > Date.now() + 60000) {
    firebaseToken = stored.firebase_token;
    firebaseUid = stored.firebase_uid;
    document.getElementById('user-email').textContent = stored.firebase_email || '';
    return true;
  }
  const tabs = await chrome.tabs.query({});
  const pikstaTab = tabs.find(t => t.url && t.url.includes('piksta.online'));
  if (!pikstaTab) { showError('Откройте piksta.online в браузере, войдите в аккаунт и попробуйте снова'); return false; }
  const results = await chrome.scripting.executeScript({
    target: { tabId: pikstaTab.id }, world: 'MAIN',
    func: async () => {
      try {
        if (typeof window.firebase === 'undefined') return { error: 'Firebase не найден на странице' };
        const user = window.firebase.auth().currentUser;
        if (!user) return { error: 'Пользователь не авторизован' };
        const token = await user.getIdToken(false);
        return { uid: user.uid, email: user.email, token };
      } catch(e) { return { error: e.message }; }
    }
  });
  const data = results[0]?.result;
  if (!data || data.error) { showError(data?.error || 'Не удалось получить токен. Обновите piksta.online и попробуйте снова'); return false; }
  firebaseToken = data.token;
  firebaseUid = data.uid;
  await chrome.storage.local.set({ firebase_token: firebaseToken, firebase_uid: firebaseUid, firebase_email: data.email, firebase_expiry: Date.now() + 50 * 60 * 1000 });
  document.getElementById('user-email').textContent = data.email || '';
  return true;
}

// ── ЗАГРУЗКА ТРЕКОВ PIKSTA ───────────────────────────────────────────────────
async function loadPikstaTracks() {
  setStep(2);
  setStatus('Шаг 2/3: загружаю треки из Piksta...');
  existingTracks = new Set();
  try {
    const url = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT}/databases/(default)/documents/users/${firebaseUid}/shipments`;
    const resp = await fetch(url, { headers: { 'Authorization': `Bearer ${firebaseToken}` } });
    if (!resp.ok) {
      if (resp.status === 401) { await chrome.storage.local.remove(['firebase_token','firebase_uid','firebase_expiry','firebase_email']); showError('Сессия истекла. Обновите piksta.online и попробуйте снова'); return false; }
      showError('Ошибка Firebase: ' + resp.status); return false;
    }
    const data = await resp.json();
    for (const shipment of data.documents || []) {
      for (const item of shipment.fields?.data?.arrayValue?.values || []) {
        const track = item.mapValue?.fields?.t?.stringValue;
        if (track) existingTracks.add(track.toLowerCase());
      }
    }
    setStatus(`Шаг 2/3: в Piksta ${existingTracks.size} треков`);
    return true;
  } catch(e) { showError('Ошибка Piksta: ' + e.message); return false; }
}

// ── ЗАГРУЗКА PDD ─────────────────────────────────────────────────────────────
async function loadPddTracks() {
  setStep(3);
  allResults = [];
  const fromDateStr = document.getElementById('from-date').value;
  const toDateStr   = document.getElementById('to-date').value;
  const fromDate = new Date(fromDateStr + 'T00:00:00').getTime() / 1000;  // начало дня "С"
  // "По дату" включительно: берём конец выбранного дня (23:59:59)
  const toDate = toDateStr ? (new Date(toDateStr + 'T23:59:59').getTime() / 1000) : Infinity;
  setStatus('Шаг 3/3: ищу вкладку Pinduoduo...');
  const allTabs = await chrome.tabs.query({});
  const pddTab = allTabs.find(t => t.url && (t.url.includes('yangkeduo.com') || t.url.includes('pinduoduo.com')));
  if (!pddTab) { showError('Откройте yangkeduo.com в любой вкладке браузера и попробуйте снова'); return false; }
  setStatus('Шаг 3/3: загружаю через вкладку Pinduoduo...');
  const progressListener = (msg) => {
    if (msg.type === 'PDD_PROGRESS') {
      if (isCancelled) return;
      setStatus(`Шаг 3/3: стр. ${msg.page}, треков: ${msg.count} — можно переключать вкладки`);
    }
  };
  chrome.runtime.onMessage.addListener(progressListener);
  const response = await chrome.runtime.sendMessage({ type: 'FETCH_PDD_TRACKS', fromDate, toDate, tabId: pddTab.id });
  chrome.runtime.onMessage.removeListener(progressListener);
  if (isCancelled) return false;
  if (!response.ok) { showError('Ошибка Pinduoduo: ' + response.error + '. Убедитесь что вы залогинены на yangkeduo.com'); return false; }
  for (const r of response.results) {
    r.isNew = !existingTracks.has(r.track.toLowerCase());
    allResults.push(r);
  }
  return true;
}

// ── ГЛАВНАЯ ФУНКЦИЯ ──────────────────────────────────────────────────────────
async function run() {
  hideError();
  allResults = [];
  cargoOrdered = [];
  cargoTracks = new Set();
  cargoReady = false;
  cargoCompared = false;
  document.getElementById('results').style.display = 'none';
  document.getElementById('action-buttons').style.display = 'none';
  document.getElementById('summary').style.display = 'none';
  document.getElementById('cargo-block').style.display = 'none';
  document.getElementById('cargo-stats').style.display = 'none';

  const btn = document.getElementById('btn-run');
  isCancelled = false;
  btn.textContent = '⏹ Стоп';
  btn.style.background = '#c00';
  btn.onclick = () => { isCancelled = true; resetResults(); btn.textContent = 'Загрузить'; btn.style.background = ''; btn.onclick = () => run(); };

  try {
    if (!await getFirebaseAuth()) { btn.textContent = 'Загрузить'; btn.style.background = ''; btn.onclick = () => run(); return; }
    if (!await loadPikstaTracks()) { btn.textContent = 'Загрузить'; btn.style.background = ''; btn.onclick = () => run(); return; }
    if (!await loadPddTracks()) { btn.textContent = 'Загрузить'; btn.style.background = ''; btn.onclick = () => run(); return; }

    const newCount   = allResults.filter(r => r.isNew).length;
    const totalCount = allResults.length;

    setStatus('✅ Готово! Загрузите файл карго для сверки.', '#2a7a2a');

    document.getElementById('summary').style.display = 'block';
    document.getElementById('count-total').textContent    = totalCount;
    document.getElementById('count-new').textContent      = newCount;
    document.getElementById('count-existing').textContent = totalCount - newCount;

    const resultsEl = document.getElementById('results');
    resultsEl.style.display = 'block';
    const newTracks = allResults.filter(r => r.isNew);
    resultsEl.textContent = newTracks.length
      ? newTracks.map((r, i) => `${String(i+1).padStart(3,'0')} ${r.track} ¥${r.price_cny} ${r.date}\n   ${r.goods.slice(0,45)}`).join('\n\n')
      : 'Новых треков нет — все уже есть в Piksta';

    // Показываем блок карго
    document.getElementById('cargo-block').style.display = 'block';
    document.getElementById('cargo-block').classList.remove('has-file');
    document.getElementById('cargo-filename').textContent = 'файл не выбран';
    document.getElementById('btn-cargo-compare').style.display = 'none';

    document.getElementById('action-buttons').style.display = 'flex';
    document.getElementById('btn-reset').style.display = 'block';

    // Сброс текста кнопки склада
    document.getElementById('btn-assign').textContent = '🏷️ Проставить склады → Piksta';

  } catch(e) {
    showError('Ошибка: ' + e.message);
  }

  btn.textContent = 'Загрузить';
  btn.style.background = '';
  btn.onclick = () => run();
}

// ── КОПИРОВАНИЕ И ЭКСПОРТ ────────────────────────────────────────────────────
async function copyTracks() {
  const text = allResults.map(r => r.track).join('\n');
  await doCopy(text, 'btn-copy');
}

async function copyNewTracks() {
  const text = allResults.filter(r => r.isNew).map(r => r.track).join('\n');
  await doCopy(text, 'btn-copy-new');
}

async function doCopy(text, btnId) {
  try {
    await navigator.clipboard.writeText(text);
    const btn = document.getElementById(btnId);
    const orig = btn.textContent;
    btn.textContent = '✅ Скопировано!';
    setTimeout(() => btn.textContent = orig, 2000);
  } catch(e) { alert(text); }
}

async function downloadCSV(onlyNew = false) {
  const data = onlyNew ? allResults.filter(r => r.isNew) : allResults;
  const suffix = onlyNew ? '_новые' : '';
  const btnId = onlyNew ? 'btn-csv-new' : 'btn-csv';
  const btn = document.getElementById(btnId);
  const origText = btn.textContent;
  btn.textContent = '⏳ Перевожу...';
  btn.disabled = true;
  setStatus(`Перевожу ${data.length} названий на русский...`);
  const translations = await translateGoods(data);
  const bom = '\uFEFF';
  const header = 'Трек-номер,Склад,Описание (RU),Описание оригинал,Цена (CNY),Дата заказа';
  const rows = data.map((r, i) => {
    const ru   = (translations[i] || r.goods || '').replace(/"/g, '""');
    const orig = (r.goods || '').replace(/"/g, '""');
    return `${r.track},"","${ru}","${orig}",${r.price_cny},${r.date}`;
  });
  const csv = bom + [header, ...rows].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `piksta_pdd_${new Date().toISOString().slice(0,10)}${suffix}.csv`;
  a.click();
  URL.revokeObjectURL(url);
  btn.textContent = origText;
  btn.disabled = false;
  setStatus('✅ Готово!', '#2a7a2a');
}

// ── СЛУШАЕМ ЗАВЕРШЕНИЕ ИМПОРТА ───────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type !== 'IMPORT_DONE') return;
  const overlay = document.createElement('div');
  overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.75);z-index:9999;display:flex;align-items:center;justify-content:center;';
  const box = document.createElement('div');
  box.style.cssText = 'background:#fff;border-radius:16px;padding:32px;text-align:center;max-width:360px;width:90%;box-shadow:0 8px 40px rgba(0,0,0,0.3);';
  box.innerHTML = `
    <div style="font-size:48px;margin-bottom:12px">✅</div>
    <div style="font-weight:700;font-size:18px;color:#1a1440;margin-bottom:8px">Импорт завершён!</div>
    <div style="font-size:13px;color:#666;margin-bottom:20px">Партия <b>${msg.shipmentName || ''}</b> сохранена в Piksta со складами.</div>
    <button id="btn-close-import" style="width:100%;background:#c00;color:#fff;border:none;border-radius:8px;padding:12px;font-size:14px;font-weight:600;cursor:pointer;">✕ Закрыть эту вкладку</button>`;
  overlay.appendChild(box);
  document.body.appendChild(overlay);
  document.getElementById('btn-close-import').addEventListener('click', () => window.close());
});
