/**
 * Piksta — Проставление складов
 * assign.js v1.8.0
 *
 * Вся логика в одном файле, без патчей.
 * Структура:
 *  1. Состояние
 *  2. Инициализация
 *  3. Рендер списка
 *  4. Обработчики событий (attachListeners)
 *  5. Действия: toggleSelect, setOne, applyToSelected, goNext, addRecent
 *  6. Прогресс и сохранение черновика
 *  7. Сброс
 *  8. Сохранение в Firebase (с диалогом подтверждения)
 */

const FIREBASE_PROJECT = 'parcel-scanner-90427';

// ── КАПИТАЛИЗАЦИЯ СКЛАДА ──────────────────────────────────────────────────────
// Каждое слово с заглавной буквы, КРОМЕ союзов/предлогов (они маленькими).
// Союз между именами ("Алеся и Яна") = сборный пакет, два разных склада.
// Без союза ("Денис Петров") = один склад (имя+фамилия одного получателя).
const WAREHOUSE_CONJUNCTIONS = new Set(['и','с','в','на','для','от','до','по','за','из','у','о','к']);
function capitalizeWarehouse(str) {
  if (!str) return str;
  return str.trim().split(/\s+/).map((word, idx) => {
    const lower = word.toLowerCase();
    // Союзы/предлоги маленькими — но НЕ первое слово (первое всегда с заглавной)
    if (idx > 0 && WAREHOUSE_CONJUNCTIONS.has(lower)) return lower;
    // Остальные слова — первая буква заглавная, остальные как есть
    return word.charAt(0).toUpperCase() + word.slice(1);
  }).join(' ');
}

// ── 1. СОСТОЯНИЕ ─────────────────────────────────────────────────────────────
let tracks      = [];       // [{track, goods, price_cny, date, thumb}, ...]
let warehouses  = {};       // {track: 'Алина', ...}
let selected    = new Set();// выделенные треки
let recent      = [];       // подсказки — только в памяти, сбрасываются при закрытии
let firebaseToken = null;
let firebaseUid   = null;
let shipmentId    = null;
let shipmentName  = '';
let assignMode    = 'exist'; // 'new' | 'exist'
let filter        = 'all';  // 'all' | 'empty' | 'filled'
let search        = '';

// ── 2. ИНИЦИАЛИЗАЦИЯ ─────────────────────────────────────────────────────────
async function init() {
  const s = await chrome.storage.local.get([
    'assign_tracks', 'assign_shipment_id', 'assign_shipment_name',
    'assign_mode', 'firebase_token', 'firebase_uid'
  ]);

  tracks        = s.assign_tracks        || [];
  shipmentId    = s.assign_shipment_id   || null;
  shipmentName  = s.assign_shipment_name || '';
  assignMode    = s.assign_mode          || 'exist';
  firebaseToken = s.firebase_token       || null;
  firebaseUid   = s.firebase_uid         || null;

  // Черновик складов из localStorage (восстанавливается если закрыл и открыл снова)
  warehouses = JSON.parse(localStorage.getItem(`wh_${shipmentId}`) || '{}');
  recent = []; // подсказки — всегда с чистого листа

  if (!tracks.length) {
    document.getElementById('track-list').innerHTML =
      '<div class="empty"><div class="empty-icon">⚠️</div><div>Нет треков. Вернитесь на страницу импорта.</div></div>';
    return;
  }

  // Топбар
  document.getElementById('topbar-count').textContent = shipmentName ? `· ${shipmentName}` : '';
  document.getElementById('total-count').textContent = tracks.length;
  document.getElementById('btn-save-all').disabled = false;

  // Кнопки топбара
  document.getElementById('btn-save-all').addEventListener('click', onSaveClick);
  document.getElementById('btn-reset-all').addEventListener('click', onResetClick);

  // Фильтры
  document.getElementById('filter-select-all').addEventListener('click', onSelectAll);
  ['all', 'empty', 'filled'].forEach(f => {
    document.getElementById(`filter-${f}`).addEventListener('click', () => {
      filter = f;
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      document.getElementById(`filter-${f}`).classList.add('active');
      // Сбрасываем "Выбрать все"
      const btn = document.getElementById('filter-select-all');
      btn.textContent = 'Выбрать все';
      btn.style.background = '';
      btn.style.color = '#F5A623';
      render();
    });
  });

  // Поиск
  document.getElementById('search-box').addEventListener('input', e => {
    search = e.target.value;
    render();
  });

  updateProgress();
  render();
}

// ── 3. РЕНДЕР ────────────────────────────────────────────────────────────────
function getVisible() {
  return tracks.filter(r => {
    const w = warehouses[r.track] || '';
    if (filter === 'empty'  && w)  return false;
    if (filter === 'filled' && !w) return false;
    if (search) {
      const q = search.toLowerCase();
      if (!r.track.toLowerCase().includes(q) && !w.toLowerCase().includes(q)) return false;
    }
    return true;
  });
}

function render() {
  const list    = document.getElementById('track-list');
  const visible = getVisible();

  if (!visible.length) {
    list.innerHTML = '<div class="empty"><div class="empty-icon">🔍</div><div>Ничего не найдено</div></div>';
    return;
  }

  list.innerHTML = visible.map(r => {
    const w          = warehouses[r.track] || '';
    const isSelected = selected.has(r.track);
    const classes    = ['track-card', w ? 'filled' : '', isSelected ? 'checked' : '', (r.qty && r.qty > 1) ? 'multi-qty' : ''].filter(Boolean).join(' ');

    const imgHtml = r.thumb
      ? `<img class="track-img" src="${r.thumb}" data-track="${r.track}"
             title="Нажмите для увеличения" data-has-error="0">
         <div class="track-img-placeholder" id="ph-${r.track}" style="display:none">📦</div>`
      : `<div class="track-img-placeholder">📦</div>`;

    const quickBtns = recent.slice(0, 5).map(wh =>
      `<button class="quick-btn" data-track="${r.track}" data-wh="${wh}">${wh}</button>`
    ).join('');

    return `
      <div class="${classes}" id="card-${r.track}" data-track="${r.track}">
        <input type="checkbox" class="track-checkbox" id="chk-${r.track}"
               data-track="${r.track}" ${isSelected ? 'checked' : ''}>
        ${imgHtml}
        <div class="track-info">
          <div class="track-num">${r.track}${(r.qty && r.qty > 1) ? ` <span class="qty-badge">×${r.qty}</span>` : ''}</div>
          <div class="track-goods">${(r.goods || '').slice(0, 55)}</div>
          <div class="track-prices">
            <label class="price-field">
              <span>Закупка ¥</span>
              <input type="number" step="0.01" inputmode="decimal" class="price-buy" data-track="${r.track}" value="${r.price_cny || ''}" onchange="onBuyPriceChange(this)">
            </label>
            <label class="price-field">
              <span>Клиент ¥</span>
              <input type="number" step="0.01" inputmode="decimal" class="price-client" data-track="${r.track}" value="${r.price_client || ''}" placeholder="${r.price_cny || '—'}" onchange="onClientPriceChange(this)">
            </label>
          </div>
          <div class="track-date">${r.date}</div>
        </div>
        <div class="track-right">
          <div class="autocomplete-wrap">
            <input class="warehouse-input${w ? ' has-value' : ''}"
                   id="w-${r.track}" data-track="${r.track}"
                   value="${w}" placeholder="Склад..." autocomplete="off">
            <div class="autocomplete-hint" id="hint-${r.track}"></div>
          </div>
          <div class="quick-warehouses" id="quick-${r.track}">${quickBtns}</div>
          <div class="saved-badge">✅ сохранено</div>
        </div>
      </div>`;
  }).join('');

  attachListeners();
}

// ── 4. ОБРАБОТЧИКИ СОБЫТИЙ ───────────────────────────────────────────────────
function onBuyPriceChange(input) {
  const track = input.dataset.track;
  const t = tracks.find(x => x.track === track);
  if (t) t.price_cny = input.value;
  // обновляем placeholder поля клиента (если клиент пуст — показывает закупку)
  const cli = document.querySelector(`.price-client[data-track="${track}"]`);
  if (cli) cli.placeholder = input.value || '—';
}

function onClientPriceChange(input) {
  const track = input.dataset.track;
  const t = tracks.find(x => x.track === track);
  if (t) t.price_client = input.value;
}

function attachListeners() {
  // Карточка — клик для выделения (не по инпуту / кнопке / картинке)
  document.querySelectorAll('.track-card').forEach(card => {
    card.addEventListener('click', e => {
      if (['INPUT', 'BUTTON'].includes(e.target.tagName)) return;
      if (e.target.classList.contains('track-img') ||
          e.target.classList.contains('quick-btn'))   return;
      toggleSelect(card.dataset.track);
    });
  });

  // Чекбоксы
  document.querySelectorAll('.track-checkbox').forEach(chk => {
    chk.addEventListener('click', e => {
      e.stopPropagation();
      toggleSelect(chk.dataset.track);
    });
  });

  // Картинки — увеличение/уменьшение + fallback при ошибке загрузки
  document.querySelectorAll('.track-img').forEach(img => {
    img.addEventListener('click', () => img.classList.toggle('expanded'));
    img.addEventListener('error', () => {
      img.style.display = 'none';
      const track = img.dataset.track;
      const ph = document.getElementById(`ph-${track}`);
      if (ph) ph.style.display = 'flex';
    });
  });

  // Быстрые кнопки
  document.querySelectorAll('.quick-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const track = btn.dataset.track;
      const wh    = btn.dataset.wh;
      if (selected.size > 0 && selected.has(track)) {
        applyToSelected(wh, track);
      } else {
        setOne(track, wh);
        goNext(track);
      }
    });
  });

  // Поля ввода
  document.querySelectorAll('.warehouse-input').forEach(input => {
    const track = input.dataset.track;

    // Ввод — обновляем склад и показываем подсказку
    input.addEventListener('input', () => {
      warehouses[track] = input.value;
      input.classList.toggle('has-value', !!input.value);
      document.getElementById(`card-${track}`)?.classList.toggle('filled', !!input.value);
      updateProgress();
      saveDraft();

      // Автодополнение
      const hint = document.getElementById(`hint-${track}`);
      if (hint) {
        const val = input.value;
        if (val.length > 0) {
          const match = recent.find(w =>
            w.toLowerCase().startsWith(val.toLowerCase()) &&
            w.toLowerCase() !== val.toLowerCase()
          );
          hint.textContent = match || '';
        } else {
          hint.textContent = '';
        }
      }
    });

    // Клавиши
    input.addEventListener('keydown', e => {
      const hint       = document.getElementById(`hint-${track}`);
      const suggestion = hint?.textContent || '';

      // Tab / → — принять подсказку
      if ((e.key === 'Tab' || e.key === 'ArrowRight') && suggestion) {
        e.preventDefault();
        input.value = suggestion;
        warehouses[track] = suggestion;
        input.classList.add('has-value');
        document.getElementById(`card-${track}`)?.classList.add('filled');
        hint.textContent = '';
        updateProgress();
        saveDraft();
        if (selected.size > 0 && selected.has(track)) {
          applyToSelected(suggestion, track);
        }
        return;
      }

      // Enter — капитализировать, сохранить и применить
      if (e.key === 'Enter') {
        e.preventDefault();
        const w = capitalizeWarehouse(input.value.trim());
        if (!w) return;
        input.value = w;                 // показываем с заглавной сразу
        warehouses[track] = w;
        input.classList.add('has-value');
        addRecent(w);
        updateProgress();
        saveDraft();
        if (selected.size > 0 && selected.has(track)) {
          applyToSelected(w, track);
        } else {
          goNext(track);
        }
      }
    });

    // Уход с поля (клик/тап на другую строку) — тоже капитализируем
    input.addEventListener('blur', () => {
      const w = capitalizeWarehouse(input.value.trim());
      if (w && w !== input.value) {
        input.value = w;
        warehouses[track] = w;
        saveDraft();
      }
      if (w) addRecent(w);
    });
  });
}

// ── 5. ДЕЙСТВИЯ ──────────────────────────────────────────────────────────────
function toggleSelect(track) {
  if (selected.has(track)) {
    selected.delete(track);
    document.getElementById(`card-${track}`)?.classList.remove('checked');
    const chk = document.getElementById(`chk-${track}`);
    if (chk) chk.checked = false;
  } else {
    selected.add(track);
    document.getElementById(`card-${track}`)?.classList.add('checked');
    const chk = document.getElementById(`chk-${track}`);
    if (chk) chk.checked = true;
  }
}

function setOne(track, value) {
  warehouses[track] = value;
  const input = document.getElementById(`w-${track}`);
  if (input) { input.value = value; input.classList.add('has-value'); }
  document.getElementById(`card-${track}`)?.classList.add('filled');
  updateProgress();
  saveDraft();
}

function applyToSelected(value, sourceTrack) {
  selected.forEach(t => {
    warehouses[t] = value;
  });
  addRecent(value);
  selected.clear();
  updateProgress();
  saveDraft();
  render();
  // Переходим к первому незаполненному — мягко, без резкого центрирования
  setTimeout(() => {
    const next = tracks.find(r => !warehouses[r.track]);
    if (next) {
      const el = document.getElementById(`w-${next.track}`);
      if (!el) return;
      el.focus({ preventScroll: true });
      el.select();
      const rect = el.getBoundingClientRect();
      if (rect.top < 150 || rect.bottom > window.innerHeight) {
        el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }
  }, 60);
}

function goNext(currentTrack) {
  const visible = getVisible();
  const idx     = visible.findIndex(r => r.track === currentTrack);
  const next    = visible[idx + 1];
  if (next) {
    setTimeout(() => {
      const el = document.getElementById(`w-${next.track}`);
      if (!el) return;
      el.focus({ preventScroll: true });  // фокус БЕЗ авто-скролла (не дёргаем страницу)
      el.select();
      // Скроллим ТОЛЬКО если следующее поле реально вне видимой зоны — и мягко (nearest)
      const rect = el.getBoundingClientRect();
      const topBar = 150; // высота залипшего хедера
      if (rect.top < topBar || rect.bottom > window.innerHeight) {
        el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }, 30);
  }
}

function addRecent(w) {
  if (!w || recent.includes(w)) return;
  recent.unshift(w);
  recent = recent.slice(0, 8);
  // Точечно обновляем быстрые кнопки во всех строках (БЕЗ полной перерисовки,
  // чтобы не вернуть баг перескакивания страницы). Автодополнение (hint) само
  // читает из recent при вводе. Так подсказки снова появляются на всех строках.
  refreshQuickButtons();
}

// Перерисовывает только блоки быстрых кнопок quick-${track} во всех строках,
// не трогая позицию скролла и фокус. Вешает обработчики заново.
function refreshQuickButtons() {
  const quickBtns = recent.slice(0, 5);
  document.querySelectorAll('.quick-warehouses').forEach(box => {
    const track = box.id.replace('quick-', '');
    box.innerHTML = quickBtns.map(wh =>
      `<button class="quick-btn" data-track="${track}" data-wh="${wh}">${wh}</button>`
    ).join('');
  });
  // заново вешаем обработчики на новые кнопки
  document.querySelectorAll('.quick-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const track = btn.dataset.track;
      const wh    = btn.dataset.wh;
      if (selected.size > 0 && selected.has(track)) {
        applyToSelected(wh, track);
      } else {
        setOne(track, wh);
        goNext(track);
      }
    });
  });
}

function onSelectAll() {
  const btn     = document.getElementById('filter-select-all');
  const visible = getVisible();
  const allSel  = visible.every(r => selected.has(r.track));
  if (allSel) {
    visible.forEach(r => selected.delete(r.track));
    btn.textContent       = 'Выбрать все';
    btn.style.background  = '';
    btn.style.color       = '#F5A623';
  } else {
    visible.forEach(r => selected.add(r.track));
    btn.textContent       = 'Снять все';
    btn.style.background  = '#F5A623';
    btn.style.color       = '#fff';
  }
  render();
}

// ── 6. ПРОГРЕСС И ЧЕРНОВИК ───────────────────────────────────────────────────
function updateProgress() {
  const filled = tracks.filter(r => warehouses[r.track]).length;
  const total  = tracks.length;
  document.getElementById('filled-count').textContent = filled;
  document.getElementById('total-count').textContent  = total;
  const pct = total ? (filled / total * 100) : 0;
  const bar = document.getElementById('progress-fill-top');
  if (bar) bar.style.width = pct + '%';
}

function saveDraft() {
  localStorage.setItem(`wh_${shipmentId}`, JSON.stringify(warehouses));
}

// ── 7. СБРОС ─────────────────────────────────────────────────────────────────
function onResetClick() {
  const filled = Object.values(warehouses).filter(Boolean).length;
  if (filled === 0) return;

  showDialog({
    icon: '⚠️',
    title: 'Сбросить склады?',
    text: `Будут удалены все заполненные склады (${filled} шт.). Это нельзя отменить.`,
    confirmText: 'Да, сбросить',
    confirmStyle: 'background:#c00;color:#fff;',
    cancelText: 'Отмена',
    onConfirm: () => {
      warehouses = {};
      selected.clear();
      localStorage.removeItem(`wh_${shipmentId}`);
      updateProgress();
      render();
    }
  });
}

// ── 8. СОХРАНЕНИЕ В FIREBASE ─────────────────────────────────────────────────
function onSaveClick() {
  const withWh    = tracks.filter(r => warehouses[r.track]);
  const withoutWh = tracks.filter(r => !warehouses[r.track]);

  if (withoutWh.length > 0) {
    // Есть треки без склада — показываем предупреждение
    showDialog({
      icon: '📦',
      title: 'Не все склады заполнены',
      text: `Заполнено складов: ${withWh.length} из ${tracks.length}.\n\n` +
            `${withoutWh.length} треков без склада останутся в новых — они появятся при следующем импорте.`,
      confirmText: `Сохранить ${withWh.length} треков`,
      confirmStyle: 'background:#6C4DB8;color:#fff;',
      cancelText: 'Вернуться и заполнить',
      onConfirm: () => saveToFirebase(withWh),
    });
  } else {
    // Все заполнены — сохраняем сразу
    saveToFirebase(withWh);
  }
}

// ── ОБНОВЛЕНИЕ ТОКЕНА ПЕРЕД СОХРАНЕНИЕМ ──────────────────────────────────────
// Всегда берём СВЕЖИЙ токен с вкладки piksta.online прямо перед записью в Firebase.
// Так переключения VPN / истёкшая сессия не мешают: токен обновляется в момент сохранения.
async function refreshFirebaseToken() {
  const tabs = await chrome.tabs.query({});
  const pikstaTab = tabs.find(t => t.url && t.url.includes('piksta.online'));
  if (!pikstaTab) {
    throw new Error('Откройте вкладку piksta.online и войдите в аккаунт — без неё нельзя обновить доступ');
  }
  const results = await chrome.scripting.executeScript({
    target: { tabId: pikstaTab.id }, world: 'MAIN',
    func: async () => {
      try {
        if (typeof window.firebase === 'undefined') return { error: 'Firebase не найден на странице piksta.online' };
        const user = window.firebase.auth().currentUser;
        if (!user) return { error: 'Вы не авторизованы на piksta.online — войдите в аккаунт' };
        const token = await user.getIdToken(true); // true = принудительно свежий
        return { uid: user.uid, token };
      } catch(e) { return { error: e.message }; }
    }
  });
  const data = results[0]?.result;
  if (!data || data.error) {
    throw new Error(data?.error || 'Не удалось обновить доступ. Обновите piksta.online и попробуйте снова');
  }
  firebaseToken = data.token;
  firebaseUid   = data.uid;
  // Сохраним свежий токен и в storage на всякий случай
  try { await chrome.storage.local.set({ firebase_token: firebaseToken, firebase_uid: firebaseUid, firebase_expiry: Date.now() + 50*60*1000 }); } catch(e) {}
}

async function saveToFirebase(tracksToSave) {
  const btn    = document.getElementById('btn-save-all');
  const status = document.getElementById('save-status');
  btn.disabled = true;
  btn.textContent = '⏳ Обновляю доступ...';

  try {
    // ВСЕГДА берём свежий токен перед сохранением (не зависим от VPN/истёкшей сессии)
    await refreshFirebaseToken();
    btn.textContent = '⏳ Сохраняю...';

    const values = tracksToSave.map(r => ({
      mapValue: { fields: {
        t:   { stringValue: r.track },
        w:   { stringValue: warehouses[r.track] || '' },
        img: { stringValue: r.thumb || '' },
        p:   { stringValue: String(r.price_cny || '') },   // цена закупки в юанях
        pc:  { stringValue: String(r.price_client || '') },  // цена клиента в юанях (для расчёта Клиенты)
        q:   { stringValue: String(r.qty || 1) }             // количество единиц под этим треком
      }}
    }));

    if (assignMode === 'new' || !shipmentId) {
      // Создаём новую партию
      const url = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT}/databases/(default)/documents/users/${firebaseUid}/shipments`;
      const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${firebaseToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ fields: {
          name:    { stringValue: shipmentName },
          created: { timestampValue: new Date().toISOString() },
          data:    { arrayValue: { values } }
        }})
      });
      if (!resp.ok) throw new Error('Ошибка создания партии: ' + resp.status);

    } else {
      // Добавляем в существующую партию
      const getUrl  = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT}/databases/(default)/documents/users/${firebaseUid}/shipments/${shipmentId}`;
      const getResp = await fetch(getUrl, { headers: { 'Authorization': `Bearer ${firebaseToken}` } });
      if (!getResp.ok) throw new Error('Ошибка чтения партии: ' + getResp.status);
      const doc      = await getResp.json();
      const existing = doc.fields?.data?.arrayValue?.values || [];
      const allVals  = [...existing, ...values];

      const patchResp = await fetch(`${getUrl}?updateMask.fieldPaths=data`, {
        method: 'PATCH',
        headers: { 'Authorization': `Bearer ${firebaseToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ fields: { data: { arrayValue: { values: allVals } } } })
      });
      if (!patchResp.ok) throw new Error('Ошибка сохранения: ' + patchResp.status);
    }

    // Успех
    localStorage.removeItem(`wh_${shipmentId}`);
    tracksToSave.forEach(r => {
      document.getElementById(`card-${r.track}`)?.classList.add('saved');
    });

    // Уведомляем страницу импорта
    chrome.tabs.query({}, tabs => {
      tabs.forEach(tab => {
        if (tab.url && tab.url.includes(chrome.runtime.getURL('page.html'))) {
          chrome.tabs.sendMessage(tab.id, { type: 'IMPORT_DONE', shipmentName });
        }
      });
    });

    // Меняем кнопки на финальные действия
    btn.style.display = 'none';
    document.getElementById('btn-reset-all').style.display = 'none';
    const wrap = btn.parentElement;
    const done = document.createElement('div');
    done.style.cssText = 'display:flex;gap:8px;align-items:center;';
    done.innerHTML = `
      <span style="color:#4ade80;font-size:13px;font-weight:600;">
        ✅ Сохранено ${tracksToSave.length} из ${tracks.length}
      </span>
      <button id="btn-go-piksta" style="background:#6C4DB8;color:#fff;border:none;border-radius:8px;padding:8px 16px;font-size:13px;font-weight:600;cursor:pointer;">
        Перейти в Piksta
      </button>
      <button id="btn-close-tab" style="background:#c00;color:#fff;border:none;border-radius:8px;width:36px;height:36px;font-size:18px;font-weight:700;cursor:pointer;line-height:1;">
        ✕
      </button>`;
    wrap.appendChild(done);

    document.getElementById('btn-go-piksta').addEventListener('click', () => {
      window.location.href = 'https://piksta.online';
    });
    document.getElementById('btn-close-tab').addEventListener('click', () => window.close());

  } catch(e) {
    btn.disabled = false;
    btn.textContent = '💾 Сохранить в Piksta';
    if (status) status.textContent = '❌ ' + e.message;
  }
}

// ── ВСПОМОГАТЕЛЬНЫЙ ДИАЛОГ ───────────────────────────────────────────────────
function showDialog({ icon, title, text, confirmText, confirmStyle, cancelText, onConfirm }) {
  const overlay = document.createElement('div');
  overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.6);z-index:1000;display:flex;align-items:center;justify-content:center;';

  const dialog = document.createElement('div');
  dialog.style.cssText = 'background:#fff;border-radius:16px;padding:28px;width:90%;max-width:380px;box-shadow:0 8px 40px rgba(0,0,0,0.3);text-align:center;';
  dialog.innerHTML = `
    <div style="font-size:36px;margin-bottom:12px">${icon}</div>
    <div style="font-weight:700;font-size:16px;color:#1a1440;margin-bottom:10px">${title}</div>
    <div style="font-size:13px;color:#666;margin-bottom:22px;white-space:pre-line;line-height:1.5">${text}</div>
    <div style="display:flex;flex-direction:column;gap:8px;">
      <button id="dlg-confirm" style="border:none;border-radius:8px;padding:11px;font-size:14px;font-weight:600;cursor:pointer;${confirmStyle}">${confirmText}</button>
      <button id="dlg-cancel"  style="border:none;border-radius:8px;padding:11px;font-size:14px;font-weight:600;cursor:pointer;background:#f4f1ff;color:#6C4DB8;">${cancelText}</button>
    </div>`;

  overlay.appendChild(dialog);
  document.body.appendChild(overlay);

  dialog.querySelector('#dlg-cancel').addEventListener('click', () => overlay.remove());
  dialog.querySelector('#dlg-confirm').addEventListener('click', () => {
    overlay.remove();
    onConfirm();
  });
}

// ── ЗАПУСК ───────────────────────────────────────────────────────────────────
init();
