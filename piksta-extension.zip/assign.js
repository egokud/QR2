/**
 * Piksta — Проставление складов
 * assign.js v1.8.0
 *
 * Вся логика в одном файле, без патчей.
 * Структура:
 *  1. Состояние
 *  2. Инициализация
 *  3. Рендер списка
 *  4. Обработчики событий (attachListeners)
 *  5. Действия: toggleSelect, setOne, applyToSelected, goNext, addRecent
 *  6. Прогресс и сохранение черновика
 *  7. Сброс
 *  8. Сохранение в Firebase (с диалогом подтверждения)
 */

const FIREBASE_PROJECT = 'parcel-scanner-90427';

// ── КАПИТАЛИЗАЦИЯ СКЛАДА ──────────────────────────────────────────────────────
// Каждое слово с заглавной буквы, КРОМЕ союзов/предлогов (они маленькими).
// Союз между именами ("Алеся и Яна") = сборный пакет, два разных склада.
// Без союза ("Денис Петров") = один склад (имя+фамилия одного получателя).
const WAREHOUSE_CONJUNCTIONS = new Set(['и','с','в','на','для','от','до','по','за','из','у','о','к']);
function capitalizeWarehouse(str) {
  if (!str) return str;
  return str.trim().split(/\s+/).map((word, idx) => {
    const lower = word.toLowerCase();
    // Союзы/предлоги маленькими — но НЕ первое слово (первое всегда с заглавной)
    if (idx > 0 && WAREHOUSE_CONJUNCTIONS.has(lower)) return lower;
    // Остальные слова — первая буква заглавная, остальные как есть
    return word.charAt(0).toUpperCase() + word.slice(1);
  }).join(' ');
}

// ── БАЗА КЛИЕНТОВ ДЛЯ ПОДСКАЗОК (1.9.17, 05.11.2026) ─────────────────────────
// Имена всех клиентов из прошлых закупок организатора. Грузятся один раз при открытии
// (сначала мгновенно из кэша chrome.storage, потом свежие из Piksta). Подсказка ищет
// без учёта регистра и «ё», по началу любого слова и с опечатками (Лиззи → Лиза).
let clientBase = {};   // {Имя: {n: число закупок, last: 'dd.mm'}}
const normName = s => String(s || '').toLowerCase().replace(/ё/g, 'е').replace(/[()«»"'.,_@\-]+/g, ' ').replace(/\s+/g, ' ').trim();
function lev(a, b) {
  if (a === b) return 0; const m = a.length, n = b.length; if (!m) return n; if (!n) return m;
  let p = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) { const c = [i]; for (let j = 1; j <= n; j++) c[j] = Math.min(p[j] + 1, c[j - 1] + 1, p[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); p = c; }
  return p[n];
}
function allClientNames(skipTrack) {
  const m = { ...clientBase };
  Object.entries(warehouses).forEach(([t, w]) => { if (t === skipTrack) return; const v = String(w || '').trim(); if (v && !m[v]) m[v] = { n: 0, here: true }; });
  return m;
}
// Подсказки: [{name, info, score}] — лучшие 5
function suggestClients(q, current, skipTrack) {
  const nq = normName(q); if (!nq) return [];
  const qw = nq.split(' '); const out = [];
  for (const [name, meta] of Object.entries(allClientNames(skipTrack))) {
    if (name === current) continue;
    const nn = normName(name); if (!nn || nn === nq) { if (nn === nq) out.push({ name, meta, score: 200 }); continue; }
    const ww = nn.split(' ');
    let score = 0;
    if (nn.startsWith(nq)) score = 100;
    else if (qw.every(x => ww.some(w => w.startsWith(x)))) score = 80;
    else if (nn.includes(nq) && nq.length >= 3) score = 60;
    else if (qw[0].length >= 3) {
      const d = Math.min(...ww.map(w => lev(qw[0], w.slice(0, Math.max(qw[0].length, w.length)))));
      if (d <= (qw[0].length >= 5 ? 2 : 1)) score = 40 - d;
    }
    if (score) out.push({ name, meta, score });
  }
  // Есть точные совпадения (по началу слова / внутри текста) — похожие по опечатке не добавляем
  const strong = out.filter(x => x.score >= 60);
  return (strong.length ? strong : out).sort((a, b) => (b.meta.here ? 1 : 0) - (a.meta.here ? 1 : 0) || b.score - a.score || (b.meta.n || 0) - (a.meta.n || 0) || a.name.localeCompare(b.name, 'ru'));
}
// То же имя в другом написании («андрей розенбаум») → как в базе
function canonClient(w, skipTrack) {
  const nw = normName(w); if (!nw) return w;
  const hit = Object.keys(allClientNames(skipTrack)).find(n => normName(n) === nw);
  return hit || w;
}
async function loadClientBase() {
  try { const c = await chrome.storage.local.get(['client_base_' + firebaseUid]); clientBase = c['client_base_' + firebaseUid] || {}; } catch (e) {}
  if (!firebaseToken || !firebaseUid) return;
  try {
    const base = {}; let pageToken = '';
    do {
      const url = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT}/databases/(default)/documents/users/${firebaseUid}/shipments?pageSize=50&mask.fieldPaths=data&mask.fieldPaths=name${pageToken ? '&pageToken=' + pageToken : ''}`;
      const r = await fetch(url, { headers: { Authorization: `Bearer ${firebaseToken}` } });
      if (!r.ok) return;
      const j = await r.json();
      for (const d of (j.documents || [])) {
        const nm = d.fields?.name?.stringValue || '';
        const dt = (nm.match(/\d{1,2}\.\d{1,2}/) || [''])[0];
        const seen = new Set();
        for (const v of (d.fields?.data?.arrayValue?.values || [])) {
          const w = (v.mapValue?.fields?.w?.stringValue || '').trim();
          if (!w || w === '???' || w === 'Я' || seen.has(w)) continue; seen.add(w);
          const ct = d.createTime || '';
          const b = base[w] || (base[w] = { n: 0, last: '', at: '' }); b.n++;
          if (ct >= b.at) { b.at = ct; b.last = dt || b.last; }   // последняя закупка — самая свежая по дате создания
        }
      }
      pageToken = j.nextPageToken || '';
    } while (pageToken);
    clientBase = base;
    chrome.storage.local.set({ ['client_base_' + firebaseUid]: base });
  } catch (e) {}
}
const plural = (n, a, b, c) => { const m = n % 10, h = n % 100; return m === 1 && h !== 11 ? a : m >= 2 && m <= 4 && (h < 12 || h > 14) ? b : c; };
const escH = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function boldMatch(name, q) {
  const nq = normName(q).split(' ')[0]; if (!nq) return escH(name);
  const words = name.split(/(\s+)/);
  return words.map(w => {
    if (!normName(w).startsWith(nq)) return escH(w);
    const k = (w.match(/^[^A-Za-zА-Яа-яЁё0-9]*/) || [''])[0].length;   // «(» перед ником не выделяем
    return `${escH(w.slice(0, k))}<b>${escH(w.slice(k, k + nq.length))}</b>${escH(w.slice(k + nq.length))}`;
  }).join('');
}
let sugIdx = -1;
const SUG_MAX = 4;   // больше — просим уточнить
function showSuggest(input) {
  const track = input.dataset.track; const box = document.getElementById(`sug-${track}`); if (!box) return;
  const q = input.value; const nq = normName(q);
  // Это имя уже вводили в этой закупке — ориентируемся на него, базу не предлагаем
  const hereSame = Object.entries(warehouses).some(([t, w]) => t !== track && normName(w) === nq);
  // Подсказки — с 3 букв; ищем по всему тексту: имя, фамилия, ник в скобках
  const list = nq.replace(/\s/g, '').length >= 3 && !hereSame ? suggestClients(q, null, track).filter(x => !(x.score === 200 && x.name === q.trim())) : [];
  if (!list.length) { box.innerHTML = ''; box.style.display = 'none'; sugIdx = -1; return; }
  // Слишком много похожих (больше 4) — не вываливаем список, просим уточнить
  if (list.length > SUG_MAX) {
    box.innerHTML = `<div class="sug-many">Похожих клиентов: ${list.length}. Пишите дальше — фамилию или ник, подберу.</div>`;
    box.style.display = 'block'; sugIdx = -1; return;
  }
  box.innerHTML = list.map((x, i) => {
    const info = x.meta.here ? 'в этой закупке' : x.meta.n ? `${x.meta.n} ${plural(x.meta.n, 'закупка', 'закупки', 'закупок')}${x.meta.last ? ' · ' + x.meta.last : ''}` : '';
    return `<div class="sug-row" data-name="${escH(x.name)}" data-i="${i}"><span class="sug-nm">${boldMatch(x.name, q)}</span><span class="sug-in">${info}</span></div>`;
  }).join('');
  box.style.display = 'block';
  sugIdx = -1; markSug(box);   // ничего не выделено: Enter оставляет то, что написано
  box.querySelectorAll('.sug-row').forEach(r => r.addEventListener('mousedown', e => { e.preventDefault(); pickSug(input, r); }));
}
function markSug(box) { box.querySelectorAll('.sug-row').forEach((r, i) => r.classList.toggle('on', i === sugIdx)); }
function hideSuggest(track) { const b = document.getElementById(`sug-${track}`); if (b) { b.style.display = 'none'; b.innerHTML = ''; } sugIdx = -1; }
function pickSug(input, row) {
  const track = input.dataset.track;
  const w = row.dataset.name;
  if (!w) return;
  input.value = w; warehouses[track] = w;
  input.classList.add('has-value'); document.getElementById(`card-${track}`)?.classList.add('filled');
  hideSuggest(track); addRecent(w); updateProgress(); saveDraft();
  if (selected.size > 0 && selected.has(track)) applyToSelected(w, track); else goNext(track);
}

// ── 1. СОСТОЯНИЕ ─────────────────────────────────────────────────────────────
function escAttr(x) { return String(x || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
let tracks      = [];       // [{track, goods, price_cny, date, thumb}, ...]
let warehouses  = {};       // {track: 'Алина', ...}
let selected    = new Set();// выделенные треки
let recent      = [];       // подсказки — только в памяти, сбрасываются при закрытии
let firebaseToken = null;
let firebaseUid   = null;
let shipmentId    = null;
let savedShipId   = '';     // 1.10.4: закупка, куда только что сохранили — её откроет «Перейти в Piksta»
let shipmentName  = '';
let assignMode    = 'exist'; // 'new' | 'exist'
let filter        = 'all';  // 'all' | 'empty' | 'filled'
let search        = '';

// ── 2. ИНИЦИАЛИЗАЦИЯ ─────────────────────────────────────────────────────────
async function init() {
  const s = await chrome.storage.local.get([
    'assign_tracks', 'assign_shipment_id', 'assign_shipment_name',
    'assign_mode', 'firebase_token', 'firebase_uid'
  ]);

  tracks        = s.assign_tracks        || [];
  shipmentId    = s.assign_shipment_id   || null;
  shipmentName  = s.assign_shipment_name || '';
  assignMode    = s.assign_mode          || 'exist';
  firebaseToken = s.firebase_token       || null;
  firebaseUid   = s.firebase_uid         || null;

  // Черновик складов из localStorage (восстанавливается если закрыл и открыл снова)
  warehouses = JSON.parse(localStorage.getItem(`wh_${shipmentId}`) || '{}');
  recent = []; // подсказки — всегда с чистого листа
  loadClientBase(); // база клиентов для подсказок (кэш сразу, свежая — в фоне)

  if (!tracks.length) {
    document.getElementById('track-list').innerHTML =
      '<div class="empty"><div class="empty-icon">⚠️</div><div>Нет треков. Вернитесь на страницу импорта.</div></div>';
    return;
  }

  // Топбар
  document.getElementById('topbar-count').textContent = shipmentName ? `· ${shipmentName}` : '';
  document.getElementById('total-count').textContent = tracks.length;
  document.getElementById('btn-save-all').disabled = false;

  // Кнопки топбара
  document.getElementById('btn-save-all').addEventListener('click', onSaveClick);
  document.getElementById('btn-reset-all').addEventListener('click', onResetClick);

  // Фильтры
  document.getElementById('filter-select-all').addEventListener('click', onSelectAll);
  document.getElementById('btn-img-retry').addEventListener('click', () => imgRetry());
  ['all', 'empty', 'filled'].forEach(f => {
    document.getElementById(`filter-${f}`).addEventListener('click', () => {
      filter = f;
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      document.getElementById(`filter-${f}`).classList.add('active');
      // Сбрасываем "Выбрать все"
      const btn = document.getElementById('filter-select-all');
      btn.textContent = 'Выбрать все';
      btn.style.background = '';
      btn.style.color = '#F5A623';
      render();
    });
  });

  // Поиск
  document.getElementById('search-box').addEventListener('input', e => {
    search = e.target.value;
    render();
  });

  updateProgress();
  render();
}

// ── 3. РЕНДЕР ────────────────────────────────────────────────────────────────
function getVisible() {
  return tracks.filter(r => {
    const w = warehouses[r.track] || '';
    if (filter === 'empty'  && w)  return false;
    if (filter === 'filled' && !w) return false;
    if (search) {
      const q = search.toLowerCase();
      if (!r.track.toLowerCase().includes(q) && !w.toLowerCase().includes(q)) return false;
    }
    return true;
  });
}

function render() {
  const list    = document.getElementById('track-list');
  const visible = getVisible();

  if (!visible.length) {
    list.innerHTML = '<div class="empty"><div class="empty-icon">🔍</div><div>Ничего не найдено</div></div>';
    return;
  }

  list.innerHTML = visible.map(r => {
    const w          = warehouses[r.track] || '';
    const isSelected = selected.has(r.track);
    const classes    = ['track-card', w ? 'filled' : '', isSelected ? 'checked' : '', (r.qty && r.qty > 1) ? 'multi-qty' : ''].filter(Boolean).join(' ');

    const imgHtml = imgHtmlFor(r);

    const quickBtns = recent.slice(0, 5).map(wh =>
      `<button class="quick-btn" data-track="${r.track}" data-wh="${wh}">${wh}</button>`
    ).join('');

    return `
      <div class="${classes}" id="card-${r.track}" data-track="${r.track}">
        <input type="checkbox" class="track-checkbox" id="chk-${r.track}"
               data-track="${r.track}" ${isSelected ? 'checked' : ''}>
        ${imgHtml}
        <div class="track-info">
          <div class="track-num"><span class="tn">${r.track}</span>${r.src ? `<span class="mk mk-${r.src === '1688' ? 'a1688' : r.src}">${r.src === 'tb' ? 'TAOBAO' : r.src === 'pz' ? 'POIZON' : r.src === '1688' ? '1688' : 'PDD'}</span>` : ''}${(r.qty && r.qty > 1) ? `<span class="qty-badge">×${r.qty}</span>` : ''}</div>
          <div class="track-goods">${escAttr(r.name || r.goods || '')}</div>${pkVarsHtml(r)}
          <div class="track-prices">
            <label class="price-field">
              <span>Закупка ¥</span>
              <input type="number" step="0.01" inputmode="decimal" class="price-buy" data-track="${r.track}" value="${r.price_cny || ''}">
            </label>
          </div>
          <div class="track-date">${r.date}</div>
        </div>
        <div class="track-right">
          <div class="autocomplete-wrap">
            <input class="warehouse-input${w ? ' has-value' : ''}"
                   id="w-${r.track}" data-track="${r.track}"
                   value="${w}" placeholder="Клиент..." autocomplete="off">
            <div class="autocomplete-hint" id="hint-${r.track}"></div>
            <div class="sug-box" id="sug-${r.track}"></div>
          </div>
          <div class="quick-warehouses" id="quick-${r.track}">${quickBtns}</div>
          <div class="saved-badge">✅ сохранено</div>
        </div>
      </div>`;
  }).join('');

  attachListeners();
}

// ── 3a. КАРТИНКИ ─────────────────────────────────────────────────────────────
// Фото Pinduoduo грузятся не все сразу, а очередью по 6 штук. Если фото не пришло
// за 12 секунд — пробуем ещё раз через сервер Piksta (/api/img). Не пришло и так —
// показываем 📦 и кнопку «Догрузить фото». Состояние хранится по треку, поэтому
// поиск и фильтры (перерисовка списка) не обрывают загрузку.
const IMG_PAR = 6;
const IMG_TIMEOUT = [12000, 20000];        // прямая ссылка, затем через сервер Piksta
const imgState = {};                       // track -> {st:'wait'|'load'|'ok'|'fail', src, n}
let imgActive = 0;

function imgUrls(u, n) {
  const bust = n ? (u.includes('?') ? '&' : '?') + 'r=' + n : '';
  const list = [u + bust];
  if (/^https:\/\/[a-z0-9.-]*pddpic\.com\//i.test(u))
    list.push('https://www.piksta.online/api/img?url=' + encodeURIComponent(u) + (n ? '&r=' + n : ''));
  return list;
}

function imgHtmlFor(r) {
  if (!r.thumb) return `<div class="track-img-placeholder">📦</div>`;
  const st = imgState[r.track] || (imgState[r.track] = { st: 'wait', n: 0 });
  if (st.st === 'ok')
    return `<img class="track-img" src="${st.src}" data-track="${r.track}" title="Нажмите для увеличения" referrerpolicy="no-referrer">`;
  if (st.st === 'fail')
    return `<div class="track-img-placeholder fail" id="ph-${r.track}" data-track="${r.track}" title="Нажмите, чтобы загрузить ещё раз">📦<small>↻ ещё раз</small></div>`;
  return `<div class="track-img-placeholder loading" id="ph-${r.track}" data-track="${r.track}"><span class="img-spin"></span></div>`;
}

function bindImg(img) {
  img.addEventListener('click', () => img.classList.toggle('expanded'));
}
function bindImgRetry(ph) {
  ph.addEventListener('click', e => { e.stopPropagation(); imgRetry([ph.dataset.track]); });
}

function imgPaint(track) {
  const ph = document.getElementById(`ph-${track}`);
  const r = tracks.find(x => x.track === track);
  if (!ph || !r) return;
  ph.outerHTML = imgHtmlFor(r);
  const el = document.getElementById(`ph-${track}`) || document.querySelector(`.track-img[data-track="${CSS.escape(track)}"]`);
  if (!el) return;
  if (el.classList.contains('track-img')) bindImg(el);
  else if (el.classList.contains('fail')) bindImgRetry(el);
}

function imgTry(track, url, step) {
  const st = imgState[track];
  const urls = imgUrls(url, st.n);
  const im = new Image();
  im.referrerPolicy = 'no-referrer';
  let done = false;
  const timer = setTimeout(() => finish(false), IMG_TIMEOUT[step] || 15000);
  function finish(ok) {
    if (done) return; done = true; clearTimeout(timer);
    im.onload = im.onerror = null;
    if (!ok) im.src = '';                                   // обрываем зависшую загрузку
    if (ok) { st.st = 'ok'; st.src = urls[step]; }
    else if (step + 1 < urls.length) { imgTry(track, url, step + 1); return; }
    else st.st = 'fail';
    imgActive--; imgPaint(track); updateImgBtn(); imgPump();
  }
  im.onload = () => finish(im.naturalWidth > 0);
  im.onerror = () => finish(false);
  im.src = urls[step];
}

function imgPump() {
  // сначала то, что сейчас на экране, затем остальное
  const order = getVisible().concat(tracks);
  for (const r of order) {
    if (imgActive >= IMG_PAR) break;
    if (!r.thumb) continue;
    const st = imgState[r.track] || (imgState[r.track] = { st: 'wait', n: 0 });
    if (st.st !== 'wait') continue;
    st.st = 'load'; imgActive++;
    imgTry(r.track, r.thumb, 0);
  }
  updateImgBtn();
}

function imgRetry(list) {
  const ids = list || Object.keys(imgState).filter(t => imgState[t].st === 'fail');
  ids.forEach(t => {
    const st = imgState[t]; if (!st || st.st !== 'fail') return;
    st.st = 'wait'; st.n++;
    const ph = document.getElementById(`ph-${t}`);
    if (ph) { ph.className = 'track-img-placeholder loading'; ph.innerHTML = '<span class="img-spin"></span>'; }
  });
  imgPump();
}

function updateImgBtn() {
  const b = document.getElementById('btn-img-retry'); if (!b) return;
  const all = Object.values(imgState);
  const fail = all.filter(x => x.st === 'fail').length;
  const busy = all.filter(x => x.st === 'wait' || x.st === 'load').length;
  if (fail && !busy) { b.style.display = ''; b.disabled = false; b.textContent = `↻ Догрузить фото (${fail})`; }
  else if (busy) { const ok = all.filter(x => x.st === 'ok').length; b.style.display = ''; b.disabled = true; b.textContent = `Фото: ${ok} из ${all.length}…`; }
  else b.style.display = 'none';
}

// ── 4. ОБРАБОТЧИКИ СОБЫТИЙ ───────────────────────────────────────────────────
function onBuyPriceChange(input) {
  const track = input.dataset.track;
  const t = tracks.find(x => x.track === track);
  if (t) t.price_cny = input.value;
  // обновляем placeholder поля клиента (если клиент пуст — показывает закупку)
  const cli = document.querySelector(`.price-client[data-track="${track}"]`);
  if (cli) cli.placeholder = input.value || '—';
}

function onClientPriceChange(input) {
  const track = input.dataset.track;
  const t = tracks.find(x => x.track === track);
  if (t) t.price_client = input.value;
}

function attachListeners() {
  // Карточка — клик для выделения (не по инпуту / кнопке / картинке)
  document.querySelectorAll('.track-card').forEach(card => {
    card.addEventListener('click', e => {
      if (['INPUT', 'BUTTON'].includes(e.target.tagName)) return;
      if (e.target.classList.contains('track-img') ||
          e.target.closest('.track-img-placeholder') ||
          e.target.classList.contains('quick-btn'))   return;
      toggleSelect(card.dataset.track);
    });
  });

  // Чекбоксы
  document.querySelectorAll('.track-checkbox').forEach(chk => {
    chk.addEventListener('click', e => {
      e.stopPropagation();
      toggleSelect(chk.dataset.track);
    });
  });

  // Картинки — увеличение/уменьшение; загрузка — через очередь (см. раздел «Картинки»)
  document.querySelectorAll('.track-img').forEach(bindImg);
  document.querySelectorAll('.track-img-placeholder.fail').forEach(bindImgRetry);
  imgPump();

  // Быстрые кнопки
  document.querySelectorAll('.quick-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const track = btn.dataset.track;
      const wh    = btn.dataset.wh;
      if (selected.size > 0 && selected.has(track)) {
        applyToSelected(wh, track);
      } else {
        setOne(track, wh);
        goNext(track);
      }
    });
  });

  // Цена закупки: в расширениях Chrome запрещены обработчики прямо в разметке (onchange="…"),
  // поэтому вешаем их здесь (1.10.1 — раньше правка цены на этой странице не сохранялась)
  document.querySelectorAll('.price-buy').forEach(inp => {
    inp.addEventListener('input', () => onBuyPriceChange(inp));
    inp.addEventListener('change', () => onBuyPriceChange(inp));
  });

  // Поля ввода
  document.querySelectorAll('.warehouse-input').forEach(input => {
    const track = input.dataset.track;

    // Ввод — обновляем склад и показываем подсказку
    input.addEventListener('input', () => {
      warehouses[track] = input.value;
      input.classList.toggle('has-value', !!input.value);
      document.getElementById(`card-${track}`)?.classList.toggle('filled', !!input.value);
      updateProgress();
      saveDraft();

      // Подсказки из базы клиентов
      showSuggest(input);
    });

    // Клавиши: ↓↑ — выбор подсказки, Enter/Tab — взять выделенную, Esc — закрыть
    input.addEventListener('keydown', e => {
      const box = document.getElementById(`sug-${track}`);
      const rows = box && box.style.display === 'block' ? [...box.querySelectorAll('.sug-row')] : [];
      if (rows.length && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
        e.preventDefault(); sugIdx = e.key === 'ArrowDown' ? (sugIdx + 1) % rows.length : (sugIdx <= 0 ? rows.length - 1 : sugIdx - 1); markSug(box); return;
      }
      if (e.key === 'Escape') { hideSuggest(track); return; }
      if ((e.key === 'Enter' || e.key === 'Tab') && rows.length && sugIdx >= 0) { e.preventDefault(); pickSug(input, rows[sugIdx]); return; }
      if (e.key === 'Enter') {
        e.preventDefault();
        const w = canonClient(capitalizeWarehouse(input.value.trim()), track);
        if (!w) return;
        input.value = w; warehouses[track] = w;
        input.classList.add('has-value');
        addRecent(w); updateProgress(); saveDraft();
        if (selected.size > 0 && selected.has(track)) applyToSelected(w, track); else goNext(track);
      }
    });

    // Уход с поля (клик/тап на другую строку) — тоже капитализируем
    input.addEventListener('blur', () => {
      hideSuggest(track);
      const w = canonClient(capitalizeWarehouse(input.value.trim()), track);
      if (w && w !== input.value) {
        input.value = w;
        warehouses[track] = w;
        saveDraft();
      }
      if (w) addRecent(w);
    });
  });
}

// ── 5. ДЕЙСТВИЯ ──────────────────────────────────────────────────────────────
function toggleSelect(track) {
  if (selected.has(track)) {
    selected.delete(track);
    document.getElementById(`card-${track}`)?.classList.remove('checked');
    const chk = document.getElementById(`chk-${track}`);
    if (chk) chk.checked = false;
  } else {
    selected.add(track);
    document.getElementById(`card-${track}`)?.classList.add('checked');
    const chk = document.getElementById(`chk-${track}`);
    if (chk) chk.checked = true;
  }
}

function setOne(track, value) {
  warehouses[track] = value;
  const input = document.getElementById(`w-${track}`);
  if (input) { input.value = value; input.classList.add('has-value'); }
  document.getElementById(`card-${track}`)?.classList.add('filled');
  updateProgress();
  saveDraft();
}

function applyToSelected(value, sourceTrack) {
  selected.forEach(t => {
    warehouses[t] = value;
  });
  addRecent(value);
  selected.clear();
  updateProgress();
  saveDraft();
  render();
  // Переходим к первому незаполненному — мягко, без резкого центрирования
  setTimeout(() => {
    const next = tracks.find(r => !warehouses[r.track]);
    if (next) {
      const el = document.getElementById(`w-${next.track}`);
      if (!el) return;
      el.focus({ preventScroll: true });
      el.select();
      const rect = el.getBoundingClientRect();
      if (rect.top < 150 || rect.bottom > window.innerHeight) {
        el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }
  }, 60);
}

function goNext(currentTrack) {
  const visible = getVisible();
  const idx     = visible.findIndex(r => r.track === currentTrack);
  const next    = visible[idx + 1];
  if (next) {
    setTimeout(() => {
      const el = document.getElementById(`w-${next.track}`);
      if (!el) return;
      el.focus({ preventScroll: true });  // фокус БЕЗ авто-скролла (не дёргаем страницу)
      el.select();
      // Скроллим ТОЛЬКО если следующее поле реально вне видимой зоны — и мягко (nearest)
      const rect = el.getBoundingClientRect();
      const topBar = 150; // высота залипшего хедера
      if (rect.top < topBar || rect.bottom > window.innerHeight) {
        el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }, 30);
  }
}

function addRecent(w) {
  if (!w || recent.includes(w)) return;
  recent.unshift(w);
  recent = recent.slice(0, 8);
  // Точечно обновляем быстрые кнопки во всех строках (БЕЗ полной перерисовки,
  // чтобы не вернуть баг перескакивания страницы). Автодополнение (hint) само
  // читает из recent при вводе. Так подсказки снова появляются на всех строках.
  refreshQuickButtons();
}

// Перерисовывает только блоки быстрых кнопок quick-${track} во всех строках,
// не трогая позицию скролла и фокус. Вешает обработчики заново.
function refreshQuickButtons() {
  const quickBtns = recent.slice(0, 5);
  document.querySelectorAll('.quick-warehouses').forEach(box => {
    const track = box.id.replace('quick-', '');
    box.innerHTML = quickBtns.map(wh =>
      `<button class="quick-btn" data-track="${track}" data-wh="${wh}">${wh}</button>`
    ).join('');
  });
  // заново вешаем обработчики на новые кнопки
  document.querySelectorAll('.quick-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const track = btn.dataset.track;
      const wh    = btn.dataset.wh;
      if (selected.size > 0 && selected.has(track)) {
        applyToSelected(wh, track);
      } else {
        setOne(track, wh);
        goNext(track);
      }
    });
  });
}

function onSelectAll() {
  const btn     = document.getElementById('filter-select-all');
  const visible = getVisible();
  const allSel  = visible.every(r => selected.has(r.track));
  if (allSel) {
    visible.forEach(r => selected.delete(r.track));
    btn.textContent       = 'Выбрать все';
    btn.style.background  = '';
    btn.style.color       = '#F5A623';
  } else {
    visible.forEach(r => selected.add(r.track));
    btn.textContent       = 'Снять все';
    btn.style.background  = '#F5A623';
    btn.style.color       = '#fff';
  }
  render();
}

// ── 6. ПРОГРЕСС И ЧЕРНОВИК ───────────────────────────────────────────────────
function updateProgress() {
  const filled = tracks.filter(r => warehouses[r.track]).length;
  const total  = tracks.length;
  document.getElementById('filled-count').textContent = filled;
  document.getElementById('total-count').textContent  = total;
  const pct = total ? (filled / total * 100) : 0;
  const bar = document.getElementById('progress-fill-top');
  if (bar) bar.style.width = pct + '%';
}

function saveDraft() {
  localStorage.setItem(`wh_${shipmentId}`, JSON.stringify(warehouses));
}

// ── 7. СБРОС ─────────────────────────────────────────────────────────────────
function onResetClick() {
  const filled = Object.values(warehouses).filter(Boolean).length;
  if (filled === 0) return;

  showDialog({
    icon: '⚠️',
    title: 'Сбросить клиентов?',
    text: `Будут удалены все проставленные клиенты (${filled} шт.). Это нельзя отменить.`,
    confirmText: 'Да, сбросить',
    confirmStyle: 'background:#c00;color:#fff;',
    cancelText: 'Отмена',
    onConfirm: () => {
      warehouses = {};
      selected.clear();
      localStorage.removeItem(`wh_${shipmentId}`);
      updateProgress();
      render();
    }
  });
}

// ── 8. СОХРАНЕНИЕ В FIREBASE ─────────────────────────────────────────────────
function onSaveClick() {
  const withWh    = tracks.filter(r => warehouses[r.track]);
  const withoutWh = tracks.filter(r => !warehouses[r.track]);

  if (withoutWh.length > 0) {
    // Есть треки без склада — показываем предупреждение
    showDialog({
      icon: '📦',
      title: 'Не у всех товаров есть клиент',
      text: `Клиент проставлен: ${withWh.length} из ${tracks.length}.\n\n` +
            `${withoutWh.length} треков без клиента останутся в новых — они появятся при следующем импорте.`,
      confirmText: `Сохранить ${withWh.length} треков`,
      confirmStyle: 'background:#6C4DB8;color:#fff;',
      cancelText: 'Вернуться и заполнить',
      onConfirm: () => saveToFirebase(withWh),
    });
  } else {
    // Все заполнены — сохраняем сразу
    saveToFirebase(withWh);
  }
}

// ── ОБНОВЛЕНИЕ ТОКЕНА ПЕРЕД СОХРАНЕНИЕМ ──────────────────────────────────────
// Всегда берём СВЕЖИЙ токен с вкладки piksta.online прямо перед записью в Firebase.
// Так переключения VPN / истёкшая сессия не мешают: токен обновляется в момент сохранения.
async function refreshFirebaseToken() {
  const tabs = await chrome.tabs.query({});
  const pikstaTab = tabs.find(t => t.url && t.url.includes('piksta.online'));
  if (!pikstaTab) {
    throw new Error('Откройте вкладку piksta.online и войдите в аккаунт — без неё нельзя обновить доступ');
  }
  const results = await chrome.scripting.executeScript({
    target: { tabId: pikstaTab.id }, world: 'MAIN',
    func: async () => {
      try {
        if (typeof window.firebase === 'undefined') return { error: 'Firebase не найден на странице piksta.online' };
        const user = window.firebase.auth().currentUser;
        if (!user) return { error: 'Вы не авторизованы на piksta.online — войдите в аккаунт' };
        const token = await user.getIdToken(true); // true = принудительно свежий
        return { uid: user.uid, token };
      } catch(e) { return { error: e.message }; }
    }
  });
  const data = results[0]?.result;
  if (!data || data.error) {
    throw new Error(data?.error || 'Не удалось обновить доступ. Обновите piksta.online и попробуйте снова');
  }
  firebaseToken = data.token;
  firebaseUid   = data.uid;
  // Сохраним свежий токен и в storage на всякий случай
  try { await chrome.storage.local.set({ firebase_token: firebaseToken, firebase_uid: firebaseUid, firebase_expiry: Date.now() + 50*60*1000 }); } catch(e) {}
}

// ── 1.10.6: РАЗНОВИДНОСТИ ПОД ОДНИМ ТРЕКОМ (r.v из background.js) ──────────────
// Карточка: «5 шт.» и свойства; если разновидностей 2+ — строчки «свойства · ×N · ¥сумма». В базу — поле v (массив): при 2+ или если у единственной есть свойства.
function pkVarsHtml(r) {
  const q = parseInt(r.qty, 10) || 1, v = Array.isArray(r.v) ? r.v : [];
  if (v.length < 2) {   // одна разновидность: штуки, цена штуки и свойства (размер/цвет), если площадка их дала
    const s = v[0] && v[0].s ? escAttr(v[0].s) : '';
    const qq = q > 1 ? `${q} шт. под треком · по ¥${(Math.round((parseFloat(r.price_cny) || 0) / q * 100) / 100).toFixed(2)}` : '';
    return qq || s ? `<div class="track-vars">${qq ? `<span>${qq}</span>` : ''}${s ? `<span>${s}</span>` : ''}</div>` : '';
  }
  return `<div class="track-vars">${v.map(x => `<span>${escAttr(x.s || 'без свойств')} · ×${x.q} · ¥${(+x.p || 0).toFixed(2)}</span>`).join('')}</div>`;
}
function pkVarsDb(r) {
  const v = Array.isArray(r.v) ? r.v : [];
  if (!v.length || (v.length === 1 && !v[0].s)) return null;   // одна разновидность без свойств — писать нечего
  return { arrayValue: { values: v.map(x => ({ mapValue: { fields: {
    s: { stringValue: String(x.s || '').slice(0, 80) }, q: { stringValue: String(x.q || 1) },
    p: { stringValue: (+x.p || 0).toFixed(2) }, ...(x.img ? { img: { stringValue: x.img } } : {})
  } } })) } };
}

async function saveToFirebase(tracksToSave) {
  const btn    = document.getElementById('btn-save-all');
  const status = document.getElementById('save-status');
  btn.disabled = true;
  btn.textContent = '⏳ Обновляю доступ...';

  try {
    // ВСЕГДА берём свежий токен перед сохранением (не зависим от VPN/истёкшей сессии)
    await refreshFirebaseToken();
    btn.textContent = '⏳ Сохраняю...';

    const values = tracksToSave.map(r => ({
      mapValue: { fields: {
        t:   { stringValue: r.track },
        w:   { stringValue: warehouses[r.track] || '' },
        img: { stringValue: r.thumb || '' },
        p:   { stringValue: String(r.price_cny || '') },   // цена закупки в юанях
        pc:  { stringValue: String(r.price_client || '') },  // цена клиента в юанях (для расчёта Клиенты)
        q:   { stringValue: String(r.qty || 1) },            // количество единиц под этим треком
        ...(r.src ? { qp: { stringValue: '1' } } : {}),                          // 1.10.6: q — точное число штук (раньше — число заказов)
        ...(r.name ? { n: { stringValue: String(r.name).slice(0, 80) } } : {}),   // 1.10.0: название товара (переведено на русский)
        ...(r.src ? { mk: { stringValue: r.src } } : {}),                         // 1.10.0: маркетплейс: pdd / tb / 1688
        ...(pkVarsDb(r) ? { v: pkVarsDb(r) } : {}),                                // 1.10.6: разновидности под треком (2+): свойства, штуки, ¥
        ...(r.fromCargo ? { src: { stringValue: 'cargo' } } : {})   // трек только из файла карго — в заказах Pinduoduo не найден
      }}
    }));

    if (assignMode === 'new' || !shipmentId) {
      // Создаём новую партию
      const url = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT}/databases/(default)/documents/users/${firebaseUid}/shipments`;
      const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${firebaseToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ fields: {
          name:    { stringValue: shipmentName },
          created: { timestampValue: new Date().toISOString() },
          data:    { arrayValue: { values } }
        }})
      });
      if (!resp.ok) throw new Error('Ошибка создания партии: ' + resp.status);
      try { const j = await resp.json(); savedShipId = String(j.name || '').split('/').pop() || ''; } catch (e) {}   // 1.10.4: id новой закупки — открыть её в Кабинете

    } else {
      // Добавляем в существующую партию
      const getUrl  = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT}/databases/(default)/documents/users/${firebaseUid}/shipments/${shipmentId}`;
      const getResp = await fetch(getUrl, { headers: { 'Authorization': `Bearer ${firebaseToken}` } });
      if (!getResp.ok) throw new Error('Ошибка чтения партии: ' + getResp.status);
      const doc      = await getResp.json();
      const existing = doc.fields?.data?.arrayValue?.values || [];
      const allVals  = [...existing, ...values];

      const patchResp = await fetch(`${getUrl}?updateMask.fieldPaths=data`, {
        method: 'PATCH',
        headers: { 'Authorization': `Bearer ${firebaseToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ fields: { data: { arrayValue: { values: allVals } } } })
      });
      if (!patchResp.ok) throw new Error('Ошибка сохранения: ' + patchResp.status);
    }

    // Успех
    if (!savedShipId && assignMode !== 'new') savedShipId = shipmentId || '';
    localStorage.removeItem(`wh_${shipmentId}`);
    tracksToSave.forEach(r => {
      document.getElementById(`card-${r.track}`)?.classList.add('saved');
    });

    // Уведомляем страницу импорта
    chrome.tabs.query({}, tabs => {
      tabs.forEach(tab => {
        if (tab.url && tab.url.includes(chrome.runtime.getURL('page.html'))) {
          chrome.tabs.sendMessage(tab.id, { type: 'IMPORT_DONE', shipmentName });
        }
      });
    });

    // Меняем кнопки на финальные действия
    btn.style.display = 'none';
    document.getElementById('btn-reset-all').style.display = 'none';
    const wrap = btn.parentElement;
    const done = document.createElement('div');
    done.style.cssText = 'display:flex;gap:8px;align-items:center;';
    done.innerHTML = `
      <span style="color:#4ade80;font-size:13px;font-weight:600;">
        ✅ Сохранено ${tracksToSave.length} из ${tracks.length}
      </span>
      <button id="btn-go-piksta" style="background:#6C4DB8;color:#fff;border:none;border-radius:8px;padding:8px 16px;font-size:13px;font-weight:600;cursor:pointer;">
        Перейти в Piksta
      </button>
      <button id="btn-close-tab" style="background:#c00;color:#fff;border:none;border-radius:8px;width:36px;height:36px;font-size:18px;font-weight:700;cursor:pointer;line-height:1;">
        ✕
      </button>`;
    wrap.appendChild(done);

    document.getElementById('btn-go-piksta').addEventListener('click', () => {
      // 1.10.4: сразу в Кабинет, в эту закупку (новую или ту, в которую добавляли), вкладка «Товары и цены»
      window.location.href = 'https://www.piksta.online/app' + (savedShipId ? '?ship=' + encodeURIComponent(savedShipId) : '');
    });
    document.getElementById('btn-close-tab').addEventListener('click', () => window.close());

  } catch(e) {
    btn.disabled = false;
    btn.textContent = '💾 Сохранить в Piksta';
    if (status) status.textContent = '❌ ' + e.message;
  }
}

// ── ВСПОМОГАТЕЛЬНЫЙ ДИАЛОГ ───────────────────────────────────────────────────
function showDialog({ icon, title, text, confirmText, confirmStyle, cancelText, onConfirm }) {
  const overlay = document.createElement('div');
  overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.6);z-index:1000;display:flex;align-items:center;justify-content:center;';

  const dialog = document.createElement('div');
  dialog.style.cssText = 'background:#fff;border-radius:16px;padding:28px;width:90%;max-width:380px;box-shadow:0 8px 40px rgba(0,0,0,0.3);text-align:center;';
  dialog.innerHTML = `
    <div style="font-size:36px;margin-bottom:12px">${icon}</div>
    <div style="font-weight:700;font-size:16px;color:#1a1440;margin-bottom:10px">${title}</div>
    <div style="font-size:13px;color:#666;margin-bottom:22px;white-space:pre-line;line-height:1.5">${text}</div>
    <div style="display:flex;flex-direction:column;gap:8px;">
      <button id="dlg-confirm" style="border:none;border-radius:8px;padding:11px;font-size:14px;font-weight:600;cursor:pointer;${confirmStyle}">${confirmText}</button>
      <button id="dlg-cancel"  style="border:none;border-radius:8px;padding:11px;font-size:14px;font-weight:600;cursor:pointer;background:#f4f1ff;color:#6C4DB8;">${cancelText}</button>
    </div>`;

  overlay.appendChild(dialog);
  document.body.appendChild(overlay);

  dialog.querySelector('#dlg-cancel').addEventListener('click', () => overlay.remove());
  dialog.querySelector('#dlg-confirm').addEventListener('click', () => {
    overlay.remove();
    onConfirm();
  });
}

// ── ЗАПУСК ───────────────────────────────────────────────────────────────────
init();
