// Background Service Worker
const API_URL = 'https://mobile.yangkeduo.com/proxy/api/api/aristotle/order_list_v4';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'FETCH_PDD_TRACKS') {
    fetchAllTracks(msg.fromDate, msg.toDate, msg.tabId)
      .then(results => sendResponse({ ok: true, results }))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
});

async function fetchAllTracks(fromDate, toDate, pddTabId) {
  const results = [];
  const seen = new Set();
  let offset = '';
  let page = 0;
  let stop = false;

  while (!stop) {
    const body = {
      type: 'all', page, size: 10, offset,
      scene: 'order_list_h5', page_from: 0,
      origin_host_name: 'mobile.yangkeduo.com',
      front_env: 1, pay_front_supports: [],
    };

    // Выполняем fetch в контексте вкладки yangkeduo (не активной — просто открытой)
    const injected = await chrome.scripting.executeScript({
      target: { tabId: pddTabId },
      world: 'MAIN',
      func: async (url, bodyData) => {
        try {
          const resp = await fetch(url, {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bodyData),
          });
          return await resp.json();
        } catch(e) { return { error: e.message }; }
      },
      args: [API_URL, body],
    });

    const data = injected[0]?.result;
    if (!data || data.error || !data.orders?.length) break;

    const last = data.orders[data.orders.length - 1];
    offset = `MO-01-${last.order_sn}`;

    for (const o of data.orders) {
      if (o.order_time < fromDate) { stop = true; break; }
      if (toDate !== undefined && o.order_time > toDate) continue;  // новее верхней границы — пропускаем
      const track = o.tracking_number;
      if (!track) continue;
      const price = (o.display_amount || 0) / 100;  // фактически оплачено за этот заказ
      const goods = o.order_goods?.[0]?.goods_name || '';
      const date = new Date(o.order_time * 1000).toISOString().slice(0, 10);
      const thumb = o.order_goods?.[0]?.thumb_url || '';

      if (seen.has(track)) {
        // ПОВТОРНЫЙ ТРЕК = ещё одна единица в той же посылке.
        // Суммируем цену и увеличиваем количество (2 кепки под 1 треком → цена ×2, qty=2)
        const existing = results.find(r => r.track === track);
        if (existing) {
          existing.qty = (existing.qty || 1) + 1;
          existing.price_cny = (parseFloat(existing.price_cny) + price).toFixed(2);
        }
        continue;
      }
      seen.add(track);
      results.push({ track, goods, price_cny: price.toFixed(2), date, thumb, qty: 1, ts: o.order_time });
    }

    // Прогресс в popup
    chrome.runtime.sendMessage({
      type: 'PDD_PROGRESS',
      page: page + 1,
      count: results.length
    }).catch(() => {});

    page++;
    await new Promise(r => setTimeout(r, 300));
  }

  return results;
}
