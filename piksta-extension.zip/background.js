// Background Service Worker
const API_URL = 'https://mobile.yangkeduo.com/proxy/api/api/aristotle/order_list_v4';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'FETCH_PDD_TRACKS') {
    // 1.9.18: вкладку Pinduoduo открывать не нужно — если её нет, откроем фоном и закроем после загрузки
    (async () => {
      const tab = msg.tabId ? { id: msg.tabId, created: false } : await ensureTab(u => /yangkeduo\.com|pinduoduo\.com/.test(u), 'https://mobile.yangkeduo.com/personal.html');
      try { return await fetchAllTracks(msg.fromDate, msg.toDate, tab.id, msg.noTrackFrom); }
      finally { if (tab.created) chrome.tabs.remove(tab.id).catch(() => {}); }
    })()
      .then(res => sendResponse({ ok: true, results: res.results, noTrack: res.noTrack }))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === 'FETCH_1688_TRACKS') {
    fetch1688Tracks(msg.fromDate, msg.toDate, msg.rangeFrom)
      .then(res => sendResponse({ ok: true, results: res.results, noTrack: res.noTrack, warn: res.warn }))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === 'FETCH_TB_TRACKS') {
    fetchTaobaoTracks(msg.fromDate, msg.toDate)
      .then(res => sendResponse({ ok: true, results: res.results, noTrack: res.noTrack }))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
});

// ── РАЗНОВИДНОСТИ ПОД ОДНИМ ТРЕКОМ (1.10.6, 10.11.2026) ─────────────────────
// r.v = [{ s: свойства (цвет/размер), q: штук, p: оплачено ¥ за эти штуки, img }]. Одинаковые свойства — одна разновидность.
// Сумма p по разновидностям = r.price_cny, сумма q = r.qty (ничего не задваиваем). В базу v пишем при 2+ разновидностях или если у одной есть свойства (размер, цвет).
function pkAddVar(r, s, q, p, img) {
  s = String(s || '').replace(/\s+/g, ' ').trim().slice(0, 80);
  q = Math.max(1, parseInt(q, 10) || 1); p = Math.round((parseFloat(p) || 0) * 100) / 100;
  r.v = r.v || [];
  const ex = r.v.find(x => x.s === s);
  if (ex) { ex.q += q; ex.p = Math.round((ex.p + p) * 100) / 100; if (!ex.img && img) ex.img = img; }
  else r.v.push({ s, q, p, img: img || '' });
}

// ── ВЕРСИЯ РАСШИРЕНИЯ ДЛЯ КАБИНЕТА (1.10.5) ─────────────────────────────────
// Открыли piksta.online — кладём на страницу номер версии (localStorage pk_ext_ver + событие pk-ext).
// Кабинет сравнивает его с актуальной (PK_EXT_VER в cabinet.js) и подсвечивает «Обновите расширение».
const PK_EXT_VERSION = chrome.runtime.getManifest().version;
function pkTellVersion(tabId) {
  chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', args: [PK_EXT_VERSION],
    func: v => { try { localStorage.setItem('pk_ext_ver', v); localStorage.setItem('pk_ext_seen', String(Date.now())); } catch (e) {} try { window.dispatchEvent(new CustomEvent('pk-ext', { detail: v })); } catch (e) {} }
  }).catch(() => {});
}
const PK_SITE = /^https:\/\/(www\.)?piksta\.online\//;
chrome.tabs.onUpdated.addListener((tabId, info, tab) => { if (info.status === 'complete' && tab && PK_SITE.test(tab.url || '')) pkTellVersion(tabId); });
function pkTellAll() { chrome.tabs.query({}).then(ts => ts.forEach(t => { if (PK_SITE.test(t.url || '')) pkTellVersion(t.id); })).catch(() => {}); }
chrome.runtime.onInstalled.addListener(pkTellAll);
chrome.runtime.onStartup.addListener(pkTellAll);

// ── ВКЛАДКА-ПОМОЩНИК ─────────────────────────────────────────────────────────
// Ищем открытую вкладку сайта; если нет — открываем фоном (не переключая пользователя) и ждём загрузки.
async function ensureTab(test, url) {
  const all = await chrome.tabs.query({});
  const ex = all.find(t => t.url && test(t.url));
  if (ex) return { id: ex.id, created: false };
  const t = await chrome.tabs.create({ url, active: false });
  await waitTabComplete(t.id, 30000);
  return { id: t.id, created: true };
}
function waitTabComplete(tabId, ms) {
  return new Promise(resolve => {
    let done = false;
    const fin = () => { if (done) return; done = true; chrome.tabs.onUpdated.removeListener(l); resolve(); };
    const l = (id, info) => { if (id === tabId && info.status === 'complete') fin(); };
    chrome.tabs.onUpdated.addListener(l);
    chrome.tabs.get(tabId).then(t => { if (t.status === 'complete') fin(); }).catch(fin);
    setTimeout(fin, ms);
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

// ── TAOBAO (1.9.18) ──────────────────────────────────────────────────────────
// Страница «已买到的宝贝» (купленные товары) уже содержит данные заказов в window._export_order_protocol:
// трек и служба доставки (orderLogistics.packageViewList), товар (orderItemInfo), магазин и дата (shopInfo).
// Вкладку открываем фоном сами, листаем кнопкой «下一页», пока заказы не станут старше даты «С», и закрываем.
const TB_LIST_URL = 'https://buyertrade.taobao.com/trade/itemlist/list_bought_items.htm';

function tbExtract() {   // выполняется ВНУТРИ страницы Taobao
  const p = window._export_order_protocol;
  if (!p) return { notReady: true, login: /login\.taobao|login\.tmall|passport/.test(location.href) };
  const V = Object.values(p), by = tag => V.filter(v => v.tag === tag);
  const shop = {}, logi = {};
  by('shopInfo').forEach(v => shop[v.id] = v.fields || {});
  by('orderLogistics').forEach(v => logi[v.id] = v.fields || {});
  const items = [];
  by('orderItemInfo').forEach(v => {
    const [oid, sub] = String(v.id).split('_');
    const it = (v.fields || {}).item || {}, s = shop[oid] || {};
    const pk = ((logi[oid] || {}).packagePreview || {}).packageViewList || [];
    const pkg = pk.find(x => (x.subOrderList || []).includes(sub)) || (pk.length === 1 ? pk[0] : null);
    const num = x => parseFloat(String(x || '').replace(/[^\d.]/g, '')) || 0;
    items.push({ oid, sub, day: s.createDay || '', time: s.createTime || '', status: s.tradeTitle || '', shop: s.shopName || '',
      track: pkg ? String(pkg.mailNo || '').trim() : '', cp: pkg ? (pkg.cpName || '') : '',
      title: it.title || '', sku: it.skuText || '', qty: parseInt(it.quantity, 10) || 1,
      price: num((it.priceInfo || {}).actualTotalFee), pic: it.pic || '' });
  });
  const orders = by('shopInfo').map(v => v.id);
  const days = by('shopInfo').map(v => (v.fields || {}).createDay || '').filter(Boolean).sort();
  const next = tbNextEl();
  function tbNextEl() {   // кнопка «下一页» (следующая страница): самый «узкий» видимый элемент с этим текстом
    const els = [...document.querySelectorAll('button,a,span,div,li')].filter(e => e.textContent.trim() === '下一页' && e.offsetParent);
    const el = els.find(e => !e.querySelector('*') || e.tagName === 'BUTTON') || els[els.length - 1];
    if (!el) return null;
    const btn = el.closest('button,a,li') || el;
    const dis = btn.disabled || btn.getAttribute('aria-disabled') === 'true' || /disabled/i.test(String(btn.className || ''));
    return dis ? null : btn;
  }
  return { items, first: orders[0] || '', oldest: days[0] || '', hasNext: !!next };
}
function tbNext() {   // выполняется ВНУТРИ страницы Taobao
  const els = [...document.querySelectorAll('button,a,span,div,li')].filter(e => e.textContent.trim() === '下一页' && e.offsetParent);
  const el = els.find(e => !e.querySelector('*') || e.tagName === 'BUTTON') || els[els.length - 1];
  const btn = el ? (el.closest('button,a,li') || el) : null;
  if (btn) btn.click();
  return !!btn;
}

async function tbRun(tabId, func) {
  const r = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func });
  return r && r[0] ? r[0].result : null;
}

async function fetchTaobaoTracks(fromDate, toDate) {
  const tab = await ensureTab(u => u.startsWith('https://buyertrade.taobao.com/trade/itemlist/'), TB_LIST_URL);
  try {
    let page = await waitTbData(tab.id);
    if (!page || page.login) throw new Error('Нет входа в Taobao — войдите на taobao.com в Chrome и повторите');
    const fromDay = new Date(fromDate * 1000 + 8 * 3600e3).toISOString().slice(0, 10);   // даты Taobao — по Пекину
    const toDay = toDate && isFinite(toDate) ? new Date(toDate * 1000 + 8 * 3600e3).toISOString().slice(0, 10) : '9999';
    const results = [], noTrack = [], byTrack = new Map();
    for (let n = 1; n <= 40; n++) {
      for (const it of page.items) {
        if (!it.day || it.day < fromDay || it.day > toDay) continue;
        if (/关闭/.test(it.status)) continue;                          // заказ закрыт (отменён/возврат)
        const ts = Math.floor(Date.parse(it.time.replace(' ', 'T') + '+08:00') / 1000) || 0;
        if (!it.track) {                                                // оплачен, но продавец ещё не отправил
          if (/付款|待发货/.test(it.status)) noTrack.push({ sn: 'tb_' + it.oid, ts });
          continue;
        }
        const ex = byTrack.get(it.track);
        const tbPic = it.pic ? (it.pic.startsWith('//') ? 'https:' + it.pic : it.pic) : '';
        if (ex) {                                                       // несколько товаров в одной посылке
          ex.qty += it.qty; ex.price_cny = (parseFloat(ex.price_cny) + it.price).toFixed(2);
          if (it.sku && !ex.sku.includes(it.sku)) ex.sku += ' + ' + it.sku;
          pkAddVar(ex, it.sku, it.qty, it.price, tbPic);
          continue;
        }
        const r = { track: it.track, goods: it.title, sku: it.sku, price_cny: it.price.toFixed(2), date: it.day, ts,
          thumb: tbPic, qty: it.qty, sn: 'tb_' + it.oid, src: 'tb', cp: it.cp };
        pkAddVar(r, it.sku, it.qty, it.price, tbPic);
        byTrack.set(it.track, r); results.push(r);
      }
      chrome.runtime.sendMessage({ type: 'TB_PROGRESS', page: n, count: results.length }).catch(() => {});
      if (!page.hasNext || (page.oldest && page.oldest < fromDay)) break;
      const prevFirst = page.first;
      await tbRun(tab.id, tbNext);
      page = null;
      for (let k = 0; k < 40; k++) {                                    // ждём, пока страница сменится
        await sleep(400);
        const p = await tbRun(tab.id, tbExtract).catch(() => null);
        if (p && !p.notReady && p.first && p.first !== prevFirst) { page = p; break; }
      }
      if (!page) break;
      await sleep(300);
    }
    return { results, noTrack };
  } finally {
    if (tab.created) chrome.tabs.remove(tab.id).catch(() => {});
  }
}
async function waitTbData(tabId) {
  for (let k = 0; k < 50; k++) {
    const p = await tbRun(tabId, tbExtract).catch(() => null);
    if (p && (p.login || !p.notReady)) return p;
    const t = await chrome.tabs.get(tabId).catch(() => null);
    if (t && /login\.taobao|login\.tmall|passport\./.test(t.url || '')) return { login: true };
    await sleep(500);
  }
  return null;
}

// ── 1688 (1.10.2, 06.11.2026) ───────────────────────────────────────────────
// Список заказов air.1688.com «已买到的货品» берём через внутренний запрос страницы lib.mtop.request:
//  • OrderListDataLineService.buyerOrderList — заказы (дата, статус, товары: название, кол-во, сумма в фэнях, фото);
//  • OrderCardDataLineService.batchQueryFulfillmentSummary — треки сразу пачкой (до 10 заказов за запрос),
//    но только у заказов «в пути» (waitbuyerreceive);
//  • MtopOrderService.queryOrder — карточка одного заказа (трек есть и у уже полученных). На частые запросы
//    1688 включает защиту от ботов (слайдер «я не робот»), запрос при этом просто висит. Поэтому карточки
//    берём только когда без них никак: заказ «в пути» без трека в пачке и полученные заказы в выбранных датах,
//    по одной, с паузой, не больше 15, каждая с ограничением 8 с; первая зависшая — останавливаемся.
const A1688_LIST_URL = 'https://air.1688.com/app/ctf-page/trade-order-list/buyer-order-list.html?page=1&pageSize=10';

async function a1688Collect(fromDay, toDay, rangeDay) {   // выполняется ВНУТРИ страницы 1688
  for (let k = 0; k < 40 && !(window.lib && window.lib.mtop && window.lib.mtop.request); k++) await new Promise(r => setTimeout(r, 250));
  if (!(window.lib && window.lib.mtop)) return { notReady: true, login: /login\.1688|login\.taobao|passport/.test(location.href) };
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const mt = (p, ms) => Promise.race([window.lib.mtop.request(p), new Promise((_, j) => setTimeout(() => j({ ret: ['TIMEOUT'] }), ms || 12000))]);
  const call = (sid, param) => mt({ api: 'mtop.1688.trading.dataline.service', v: '1.0', type: 'POST', dataType: 'jsonp', ecode: 1,
    data: { serviceId: sid, param: JSON.stringify(param) } }).then(r => { const d = r.data && r.data.data ? r.data.data : r.data; return typeof d.result === 'string' ? JSON.parse(d.result) : d.result; });
  const orders = [];
  try {
    for (let page = 1; page <= 20; page++) {
      const L = await call('OrderListDataLineService.buyerOrderList', { page, pageSize: 50 });
      const list = (L && L.data && L.data.data) || [];
      let older = false;
      for (const o of list) {
        const day = String(o.gmtCreate || '').slice(0, 10);
        if (day < fromDay) { older = true; continue; }
        if (day > toDay) continue;
        orders.push(o);
      }
      if (older || list.length < 50 || page >= ((L.data && L.data.pages) || 1)) break;
      await wait(400);
    }
  } catch (e) {
    const ret = String((e && e.ret) || e || '');
    return { error: true, login: /SESSION|LOGIN|TOKEN_EMPTY|未登录/i.test(ret), robot: /TIMEOUT|RGV587|punish/i.test(ret), msg: ret.slice(0, 120) };
  }
  const want = orders.filter(o => !/cancel|terminated|waitbuyerpay/.test(o.status));
  // 1) треки пачкой у заказов «в пути»
  const entryTrack = {}, orderTrack = {}, orderCp = {};
  const moving = want.filter(o => o.status === 'waitbuyerreceive').map(o => o.idStr);
  for (let i = 0; i < moving.length; i += 10) {
    try {
      const F = await call('OrderCardDataLineService.batchQueryFulfillmentSummary', { orderIds: moving.slice(i, i + 10) });
      for (const f of (F || [])) for (const d of (f.displayItems || [])) {
        let w = '', cp = '';
        (d.progressLines || []).forEach(l => (l.segments || []).forEach((sg, n, arr) => {
          if (sg.semanticType === 'WAYBILL_NO') { w = String(sg.copyValue || sg.text || '').trim(); const prev = arr[n - 1]; if (prev && prev.semanticType === 'NORMAL') cp = String(prev.text || '').trim(); }
        }));
        if (!w) continue;
        (d.orderEntryIds || []).forEach(id => { entryTrack[String(id)] = w; });
        if (!orderTrack[f.orderId]) { orderTrack[f.orderId] = w; orderCp[f.orderId] = cp; }
      }
    } catch (e) {}
    await wait(300);
  }
  // 2) карточки по одной — только где без них никак
  let robot = false, cards = 0;
  const needCard = want.filter(o => !orderTrack[o.idStr] && (o.status === 'waitbuyerreceive' || (o.status === 'success' && String(o.gmtCreate).slice(0, 10) >= rangeDay)));
  for (const o of needCard.slice(0, 15)) {
    try {
      const r = await mt({ api: 'mtop.1688.MtopOrderService.queryOrder', v: '1.0', data: { orderId: o.idStr, deSensitiveOrder: true } }, 8000);
      const m = (r.data && (r.data.model || (r.data.data && r.data.data.model))) || {};
      cards++;
      const bill = String((m.logistics || {}).billNo || '').trim();
      if (bill) { orderTrack[o.idStr] = bill; orderCp[o.idStr] = (m.logistics || {}).logisticsCompanyName || ''; }
      (m.orderEntries || []).forEach(e => { const t = String(((e.extensionInfo || {}).entryExtension || {}).trackingNo || '').trim(); if (t) entryTrack[String(e.id || e.entryId)] = t; });
    } catch (e) {
      if (/TIMEOUT|RGV587|punish|FAIL_SYS_USER_VALIDATE/i.test(String((e && e.ret) || e))) { robot = true; break; }
    }
    await wait(900);
  }
  const items = [], noTrack = [];
  for (const o of want) {
    if (o.status === 'waitsellersend') { noTrack.push({ oid: o.idStr, time: o.gmtCreate }); continue; }
    for (const e of (o.orderEntries || [])) {
      const track = entryTrack[String(e.entryId)] || orderTrack[o.idStr] || '';
      const si = (e.specInfo && e.specInfo.specItems) || (Array.isArray(e.specInfo) ? e.specInfo : []);
      const spec = si.map(x => x.specValue || x.value || '').filter(Boolean).join(', ');
      const q = e.quantity && typeof e.quantity === 'object' ? (e.quantity.realAmount || parseFloat(e.quantity.realAmountStr)) : parseFloat(e.quantity);
      items.push({ oid: o.idStr, time: o.gmtCreate, status: o.status, track, cp: orderCp[o.idStr] || '', title: e.productName || '', sku: spec,
        qty: Math.max(1, Math.round(q || 1)), price: (parseFloat(e.amount) || 0) / 100, pic: e.mainSummImageUrl || '' });
    }
  }
  return { items, noTrack, orders: orders.length, robot, cards, skipped: Math.max(0, needCard.length - 15) };
}

// Картинки 1688 лежат на cbu01/cbu02.alicdn.com — этот сервер не отдаёт их чужим сайтам (в Piksta были пустые
// квадраты). Тот же файл есть на открытом img.alicdn.com; берём уменьшенную копию 200×200, как у Taobao.
function a1688Img(u) {
  u = String(u || '').trim();
  if (!u) return '';
  u = u.replace(/^(https?:)?\/\//i, 'https://').replace(/^https:\/\/cbu0\d\.alicdn\.com\//i, 'https://img.alicdn.com/');
  return /\.(jpe?g|png|webp)$/i.test(u) && !/_\d+x\d+\./.test(u) ? u + '_200x200.jpg' : u;
}

async function fetch1688Tracks(fromDate, toDate, rangeFrom) {
  const tab = await ensureTab(u => u.startsWith('https://air.1688.com/app/ctf-page/trade-order-list/'), A1688_LIST_URL);
  try {
    const bj = ts => new Date(ts * 1000 + 8 * 3600e3).toISOString().slice(0, 10);   // даты 1688 — по Пекину
    const fromDay = bj(fromDate);
    const rangeDay = rangeFrom ? bj(rangeFrom) : fromDay;
    const toDay = toDate && isFinite(toDate) ? bj(toDate) : '9999';
    let res = null;
    for (let k = 0; k < 3 && !res; k++) {
      const r = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: a1688Collect, args: [fromDay, toDay, rangeDay] }).catch(() => null);
      res = r && r[0] ? r[0].result : null;
      if (res && res.notReady && !res.login) { res = null; await sleep(1500); }
    }
    const t = await chrome.tabs.get(tab.id).catch(() => null);
    if (!res || res.login || (t && /login\.1688|login\.taobao|passport\./.test(t.url || '')))
      throw new Error('Нет входа в 1688 — войдите на 1688.com в Chrome и повторите');
    if (res.error && res.robot) throw new Error('1688 просит пройти проверку «я не робот» — откройте 1688.com в Chrome, пройдите её и повторите');
    if (res.error) throw new Error('1688 не отдал заказы: ' + res.msg);
    const results = [], byTrack = new Map();
    const tsOf = s => Math.floor(Date.parse(String(s).replace(' ', 'T') + '+08:00') / 1000) || 0;
    for (const it of res.items) {
      if (!it.track) continue;
      const ex = byTrack.get(it.track);
      if (ex) {                                                       // несколько товаров в одной посылке
        ex.qty += it.qty; ex.price_cny = (parseFloat(ex.price_cny) + it.price).toFixed(2);
        if (it.sku && !ex.sku.includes(it.sku)) ex.sku += ' + ' + it.sku;
        pkAddVar(ex, it.sku, it.qty, it.price, a1688Img(it.pic));
        continue;
      }
      const r = { track: it.track, goods: it.title, sku: it.sku, price_cny: it.price.toFixed(2), date: String(it.time).slice(0, 10), ts: tsOf(it.time),
        thumb: a1688Img(it.pic), qty: it.qty, sn: 'a1688_' + it.oid, src: '1688', cp: it.cp };
      pkAddVar(r, it.sku, it.qty, it.price, a1688Img(it.pic));
      byTrack.set(it.track, r); results.push(r);
    }
    const noTrack = res.noTrack.map(x => ({ sn: 'a1688_' + x.oid, ts: tsOf(x.time) }));
    const warn = res.robot ? '1688 попросил проверку «я не робот» — часть полученных заказов без треков. Откройте 1688.com, пройдите проверку и повторите импорт'
      : res.skipped ? `1688: ещё ${res.skipped} полученных заказов не проверены — сузьте даты` : '';
    return { results, noTrack, warn };
  } finally {
    if (tab.created) chrome.tabs.remove(tab.id).catch(() => {});
  }
}

// fromDate — нижняя граница просмотра (с запасом назад для поздних отправок), noTrackFrom — с какой даты
// запоминать заказы, которые продавец ещё не отправил (без трека).
async function fetchAllTracks(fromDate, toDate, pddTabId, noTrackFrom) {
  const results = [];
  const noTrack = [];
  const seen = new Set();
  let offset = '';
  let page = 0;
  let stop = false;

  while (!stop) {
    const body = {
      type: 'all', page, size: 10, offset,
      scene: 'order_list_h5', page_from: 0,
      origin_host_name: 'mobile.yangkeduo.com',
      front_env: 1, pay_front_supports: [],
    };

    // Выполняем fetch в контексте вкладки yangkeduo (не активной — просто открытой)
    const injected = await chrome.scripting.executeScript({
      target: { tabId: pddTabId },
      world: 'MAIN',
      func: async (url, bodyData) => {
        try {
          const resp = await fetch(url, {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bodyData),
          });
          return await resp.json();
        } catch(e) { return { error: e.message }; }
      },
      args: [API_URL, body],
    });

    const data = injected[0]?.result;
    if (!data || data.error || !data.orders?.length) break;

    const last = data.orders[data.orders.length - 1];
    offset = `MO-01-${last.order_sn}`;

    for (const o of data.orders) {
      if (o.order_time < fromDate) { stop = true; break; }
      if (toDate !== undefined && o.order_time > toDate) continue;  // новее верхней границы — пропускаем
      const track = o.tracking_number;
      if (!track) {
        // оплачен, но ещё не отправлен — запомним, чтобы подхватить при следующем импорте
        const st = String(o.order_status_prompt || '');
        if (o.order_time >= (noTrackFrom || fromDate) && /待发货|待分享|拼单/.test(st)) noTrack.push({ sn: o.order_sn, ts: o.order_time });
        continue;
      }
      const price = (o.display_amount || 0) / 100;  // фактически оплачено за этот заказ (все штуки)
      const og = o.order_goods || [];
      const goods = og[0]?.goods_name || '';
      const date = new Date(o.order_time * 1000).toISOString().slice(0, 10);
      const thumb = og[0]?.thumb_url || '';
      // 1.10.6: штуки в заказе — goods_number (раньше не читали: 5 фильтров в одном заказе были «×1»).
      // В заказе Pinduoduo одна разновидность (sku), её свойства — spec. Разные разновидности = разные заказы.
      const pcs = og.reduce((n, g) => n + (parseInt(g.goods_number, 10) || 1), 0) || 1;
      const spec = og.map(g => g.spec || '').filter(Boolean).join('; ');

      if (seen.has(track)) {
        // ПОВТОРНЫЙ ТРЕК = ещё один заказ (разновидность) в той же посылке: штуки и цену складываем
        const existing = results.find(r => r.track === track);
        if (existing) {
          existing.qty = (existing.qty || 1) + pcs;
          existing.price_cny = (parseFloat(existing.price_cny) + price).toFixed(2);
          pkAddVar(existing, spec, pcs, price, thumb);
        }
        continue;
      }
      seen.add(track);
      const r = { track, goods, price_cny: price.toFixed(2), date, thumb, qty: pcs, ts: o.order_time, sn: o.order_sn, src: 'pdd' };
      pkAddVar(r, spec, pcs, price, thumb);
      results.push(r);
    }

    // Прогресс в popup
    chrome.runtime.sendMessage({
      type: 'PDD_PROGRESS',
      page: page + 1,
      count: results.length
    }).catch(() => {});

    page++;
    await new Promise(r => setTimeout(r, 300));
  }

  return { results, noTrack };
}
